#!/usr/bin/env python3
"""Released test-only answer update. Defaults to host-only validation.

This is a separate physical runner, not a modification of the emulator helper.
It never enumerates owner files, resets data, runs a test suite, or drives UI.
All APK/model/input paths must be explicitly supplied in the reviewed release.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

SERIAL = "52241FDKD000LV"
CERT = "75bcae7118a4635dd0fb153438e5bdbfd7aab5d467b3a0c2bb210eefde5becf9"
MODEL = "2c5f9a121ae6695208e300c16acca303669afa4e18812061164dca9c97071b12"
FIXTURE = "ccd9bb4cad984929ec679ecc1f2f79d249d274376fb3c00f4b529911dfaed5d0"
CASE_SET = "8ea60c32cc7d19ee0e52c4ea501408b168b5540979f5c41e18197df27a3d26e0"
TEMPLATE = "cd8e9439f0570856fd70470bf8889ebd8b5d1107207f67a5efb46e342330527f"
APP_SOURCE = "5ae91c238612bdd9b1511b3716d34b4fa5960dd2"
APP_APK = "1f83b71c5fe60a6dc26fcac7a4c75b49fbf009b6e8c9d972b2176c18081c1323"
NATIVE_APK = "bb1b2f496f6c831ced00f20d9dd08d6f571d87fcb48040dfba17f4a7c561f342"
HOST_IDENTITY = "625212a9771344d4069f06209fee7cf75b5e4bb375542932d43081b72c4463f2"
MODEL_BLAKE3 = "db158ff62057f42fef73363387db4bfac01da469475840dc0aad5dae70eb0e4a"
TEST_ONLY_PATHS = {
    "app/src/syntheticBenchmark/kotlin/app/skein/benchmark/SyntheticAnswerBenchmarkTest.kt",
    "app/src/syntheticBenchmarkShared/kotlin/app/skein/benchmark/SyntheticSetup.kt",
    "app/src/syntheticBenchmarkTest/kotlin/app/skein/benchmark/SyntheticSetupTest.kt",
}
NATIVE = "app.skein.inference.service.test"
PHASES = {
    "parity": (NATIVE, NATIVE + "/androidx.test.runner.AndroidJUnitRunner",
               "app.skein.inference.service.SyntheticTemplateParityTest#publicModelNativeTokenParity"),
    "answers": ("app.skein", "app.skein.test/androidx.test.runner.AndroidJUnitRunner",
                "app.skein.benchmark.SyntheticAnswerBenchmarkTest#suppliedEvidenceThroughTheIsolatedApk"),
}
PACKAGES = {"app": "app.skein", "app_test": "app.skein.test", "native_test": NATIVE}
SAMPLING = dict(temperature=0.0, top_k=1, top_p=1.0, min_p=0.0,
                repeat_penalty=1.0, max_tokens=256, stop=[])


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def pinned_json(record, description):
    require(re.fullmatch(r"[0-9a-f]{64}", record["sha256"]), f"bad {description} pin")
    require(digest(record["path"]) == record["sha256"], f"{description} hash mismatch")
    return json.loads(Path(record["path"]).read_text())


def host_model_identity(release):
    record = release["host_model_identity"]
    require(record["sha256"] == HOST_IDENTITY, "unreviewed host model identity")
    evidence = pinned_json(record, "host model identity")
    model = evidence["model"]
    require(evidence["status"] == "COMPLETE_HOST_PUBLIC_MODEL_IDENTITY" and
            evidence["timed_out"] is False and evidence["model_stat_unchanged"] is True and
            evidence["candidate_source_sha"] == APP_SOURCE, "incomplete host model identity")
    require(model["event"] == "complete" and model["sha256"] == MODEL and
            type(model["bytes"]) is int and model["bytes"] == 1590475744 and
            model["blake3"] == MODEL_BLAKE3, "host model identity binding mismatch")
    return dict(schema_version=1, model_sha256=MODEL, model_size=model["bytes"],
                blake3=MODEL_BLAKE3, evidence_sha256=record["sha256"])


def validate_test_only_release(release):
    require(release.get("test_only_update") is True, "test revision requires explicit test-only policy")
    require(release["source_sha"] == release["ordinary_source_sha"] == APP_SOURCE,
            "production source changed in test-only release")
    require(re.fullmatch(r"[0-9a-f]{40}", release["test_build_sha"]) and
            release["test_build_sha"] != APP_SOURCE, "new test source must be separately attested")
    require(release["apks"]["app"]["sha256"] == release["expected_installed_app_sha256"] == APP_APK,
            "test-only release must preserve current production APK")
    require(release["apks"]["native_test"]["sha256"] == NATIVE_APK,
            "test-only release changed native APK")
    review = pinned_json(release["test_only_source_review"], "test-only source review")
    require(review["approved"] is True and review["production_app_unchanged"] is True and
            review["native_test_unchanged"] is True and review["app_source_sha"] == APP_SOURCE and
            review["test_build_sha"] == release["test_build_sha"], "test-only scope not approved")
    paths = review["changed_paths"]
    require(paths and len(paths) == len(set(paths)) and set(paths).issubset(TEST_ONLY_PATHS),
            "scope includes non-test or unreviewed source")
    require(digest(release["preparation_helper"]) == release["preparation_helper_sha256"],
            "preparation helper hash mismatch")
    host_model_identity(release)
    require(release["parity_reuse"]["approved"] is True, "native parity reuse not explicitly approved")


def verify_parity_reuse(release, summary_path):
    reuse = release["parity_reuse"]
    require(reuse["approved"] is True, "native parity reuse not explicitly approved")
    require(Path(summary_path).resolve() == Path(reuse["summary"]["path"]).resolve(),
            "parity summary differs from reviewed reuse record")
    prior = pinned_json(reuse["summary"], "prior parity summary")
    report = pinned_json(reuse["report"], "prior parity report")
    old_release = pinned_json(reuse["release"], "prior parity release")
    require(old_release["authorization"] == "RELEASED_FOR_PHYSICAL_SYNTHETIC" and
            old_release["source_sha"] == APP_SOURCE and
            prior["release_sha256"] == reuse["release"]["sha256"] and
            prior["source_sha"] == APP_SOURCE, "stale or rejected parity release")
    require(old_release["apks"].get("app", {}).get("sha256") ==
            release["apks"]["app"]["sha256"] == APP_APK,
            "prior released app identity changed since parity")
    execution = prior["instrumentation"]
    require(prior["complete"] is True and prior["executed"] is True and prior["phase"] == "parity" and
            execution["remote_stop_verified"] is True and execution["junit_passed"] is True and
            execution["exit_code"] == 0 and execution["host_timeout"] is False,
            "incomplete or rejected native parity")
    require(Path(prior["collected"]["native-parity.json"]).resolve() ==
            Path(reuse["report"]["path"]).resolve(), "parity report differs from collected artifact")
    require(prior["installed_apks"]["native_test"]["sha256"] ==
            old_release["apks"]["native_test"]["sha256"] ==
            release["apks"]["native_test"]["sha256"] == NATIVE_APK,
            "native APK changed since parity")
    require(old_release["llama_sha"] == release["llama_sha"] and
            old_release["tokenizer_overlay_sha256"] == release["tokenizer_overlay_sha256"],
            "native implementation pins changed since parity")
    verify_parity(report, prior["run_id"])
    verify_native_eog(report)
    return dict(approved=True, prior_release_sha256=reuse["release"]["sha256"],
                prior_summary_sha256=reuse["summary"]["sha256"],
                prior_report_sha256=reuse["report"]["sha256"],
                native_apk_sha256=NATIVE_APK, model_sha256=MODEL, template_sha256=TEMPLATE,
                scope="native five-case token parity and classification; generated stopping unmeasured")


def verify_native_eog(report):
    """Bind reuse to the reviewed classification facts, never generated stop quality."""
    eog = report.get("native_eog")
    require(isinstance(eog, dict) and set(eog) ==
            {"scope", "declared_eos", "controls", "generated_stop_behavior"},
            "native EOG classification report missing or malformed")
    require(eog["scope"] == "classification-only" and eog["generated_stop_behavior"] == "unmeasured",
            "native EOG scope or generated-stop claim changed")
    declared = eog["declared_eos"]
    require(isinstance(declared, dict) and set(declared) == {"token_id", "is_eog"} and
            type(declared["token_id"]) is int and declared["token_id"] == 151645 and
            declared["is_eog"] is True, "native declared EOS classification changed")
    controls = eog["controls"]
    expected = {"<|im_end|>": 151645, "<|endoftext|>": 151643, "</s>": 128247}
    require(isinstance(controls, list) and len(controls) == len(expected),
            "native EOG control inventory changed")
    seen = set()
    for control in controls:
        require(isinstance(control, dict) and set(control) ==
                {"spelling", "token_ids", "singleton", "classifications"},
                "native EOG control malformed")
        spelling = control["spelling"]
        require(isinstance(spelling, str) and spelling in expected and spelling not in seen,
                "native EOG control spelling changed or duplicated")
        token = expected[spelling]
        ids = control["token_ids"]
        require(isinstance(ids, list) and len(ids) == 1 and type(ids[0]) is int and
                ids[0] == token and control["singleton"] is True,
                "native EOG control token/singleton changed")
        classes = control["classifications"]
        require(isinstance(classes, list) and len(classes) == 1 and isinstance(classes[0], dict) and
                set(classes[0]) == {"token_id", "is_eog"} and type(classes[0]["token_id"]) is int and
                classes[0]["token_id"] == token and classes[0]["is_eog"] is True,
                "native EOG control classification changed")
        seen.add(spelling)


def inject_test_metadata(release, config_path):
    config = json.loads(Path(config_path).read_text())
    require(config["build_sha"] == APP_SOURCE and config["expected_apk_sha256"] == APP_APK and
            config["model_sha256"] == MODEL and config["model_size"] == 1590475744,
            "prepared config production/model identity mismatch")
    require("test_build_sha" not in config and "host_model_identity" not in config,
            "prepared config already contains test identity; never overwrite")
    config["test_build_sha"] = release["test_build_sha"]
    config["host_model_identity"] = host_model_identity(release)
    save(config_path, config)


def install_for_phase(fold, phase):
    require(fold.r.get("test_only_update") is True, "v4 requires explicit test-only policy")
    require(phase == "answers", "test-only release authorizes answer phase only")
    current = fold.apk("app.skein", "current-app")
    require(current and current["sha256"] == fold.r["expected_installed_app_sha256"] == APP_APK,
            "current installed app mismatch; abort before any install")
    return {"app": current, "app_test": fold.install("app_test")}


def review_setup_progress(path, run_id, collected_verified):
    """Diagnostic only. Preserve raw partial bytes and never turn progress into success."""
    review = dict(path=str(path), collected_verified=collected_verified, valid_rows=0,
                  format_valid=False, errors=[], last=None, setup_success_claimed=False)
    if not Path(path).is_file():
        review["errors"].append("missing_file")
        return review
    raw = Path(path).read_bytes()
    review.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    if len(raw) > 256 * 1024:
        review["errors"].append("file_too_large")
        return review
    phases = {"config", "fixture", "app_apk_hash", "model_hash", "store", "test_apk_hash",
              "manifest", "session_unlock", "engine_load"}
    fields = {"schema_version", "run_id", "sequence", "phase", "event", "elapsed_ms",
              "bytes_processed", "total_bytes", "error_code"}
    previous_elapsed = -1
    lines = raw.splitlines()
    if not raw.endswith(b"\n"):
        review["errors"].append("unterminated_final_line")
    for index, line in enumerate(lines):
        try:
            row = json.loads(line)
            require(len(line) <= 1024 and index < 256 and isinstance(row, dict) and set(row) == fields,
                    "bad_row_shape")
            require(type(row["schema_version"]) is int and row["schema_version"] == 1 and
                    row["run_id"] == run_id and type(row["sequence"]) is int and row["sequence"] == index,
                    "bad_row_identity")
            require(row["phase"] in phases and row["event"] in {"start", "progress", "complete", "error"},
                    "bad_phase_or_event")
            require(type(row["elapsed_ms"]) is int and row["elapsed_ms"] >= previous_elapsed and
                    row["elapsed_ms"] >= 0, "bad_elapsed_time")
            for key in ("bytes_processed", "total_bytes"):
                require(row[key] is None or (type(row[key]) is int and row[key] >= 0), "bad_byte_count")
            require(row["bytes_processed"] is None or (row["total_bytes"] is not None and
                    row["bytes_processed"] <= row["total_bytes"]), "bad_byte_count")
            require((row["error_code"] in {"CANCELLED", "IO_ERROR", "VALIDATION_FAILED", "SETUP_FAILED"})
                    if row["event"] == "error" else row["error_code"] is None, "bad_error_code")
            previous_elapsed = row["elapsed_ms"]
            review["valid_rows"] += 1
            review["last"] = {key: row[key] for key in ("phase", "event", "elapsed_ms", "bytes_processed",
                                                       "total_bytes", "error_code")}
        except (ValueError, TypeError, KeyError, UnicodeError):
            review["errors"].append(f"invalid_row_{index + 1}")
            break
    if not lines:
        review["errors"].append("empty_file")
    review["format_valid"] = bool(lines) and not review["errors"]
    return review


class Commands:
    def __init__(self, output):
        self.output = output
        self.counter = 0

    def run(self, name, argv, timeout=30, stdin=None, allowed=(0,), binary_to=None):
        self.counter += 1
        stem = self.output / f"{self.counter:03}-{name}"
        started = time.monotonic()
        output = binary_to or Path(str(stem) + ".stdout")
        with output.open("xb") as stream, Path(str(stem) + ".stderr").open("xb") as error:
            try:
                result = subprocess.run(argv, stdin=stdin, stdout=stream, stderr=error,
                                        timeout=timeout)
                code = result.returncode
            except subprocess.TimeoutExpired:
                code = 124
        save(str(stem) + ".command.json", dict(argv=argv, exit_code=code,
             timeout_seconds=timeout, elapsed_seconds=round(time.monotonic() - started, 3)))
        require(code in allowed, f"{name} failed with {code}; retained {stem}")
        return code, b"" if binary_to else output.read_bytes()

    def capture(self, name, argv, timeout=30):
        """Transient query bytes; caller records minimal proof and validates exit."""
        self.counter += 1
        stem = self.output / f"{self.counter:03}-{name}"
        started = time.monotonic()
        try:
            result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
            code, stdout, stderr = result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired as error:
            code, stdout, stderr = 124, error.stdout or b"", error.stderr or b""
        save(str(stem) + ".command.json", dict(argv=argv, exit_code=code,
             timeout_seconds=timeout, elapsed_seconds=round(time.monotonic() - started, 3),
             stdout_bytes=len(stdout), stdout_sha256=hashlib.sha256(stdout).hexdigest(),
             stderr_bytes=len(stderr), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
             raw_output_retained=False))
        return code, stdout, stderr


def validate(release, commands):
    require(release["authorization"] == "RELEASED_FOR_PHYSICAL_SYNTHETIC", "candidate not released")
    validate_test_only_release(release)
    for field in ("source_sha", "llama_sha"):
        require(re.fullmatch(r"[0-9a-f]{40}", release[field]), f"bad {field}")
    require(release["ordinary_source_sha"] == release["source_sha"], "ordinary/source mismatch")
    for field in ("ordinary_reviewed", "final_source_scope_reviewed", "owner_idle_authorized",
                  "exact_target_force_stop_approved", "opt_in_build_confirmed"):
        require(release.get(field) is True, f"release requires {field}")
    require(release["coordinator_release_reference"], "missing coordinator release evidence")
    require(release["checks"] and all(c["status"] == "PASS" and c["evidence"]
                                      for c in release["checks"]), "required checks not passed")
    ordinary = []
    skipped = set()
    allowed_skips = set(release.get("allowed_ordinary_skips", []))
    require({x["module"] for x in release["ordinary_xml"]} == {"app", "vault", "inference-service"},
            "ordinary module inventory incomplete")
    for record in release["ordinary_xml"]:
        require(digest(record["path"]) == record["sha256"], "ordinary XML hash mismatch")
        root = ET.parse(record["path"]).getroot()
        require(all(int(s.attrib.get(k, 0)) == 0 for s in root.iter("testsuite")
                    for k in ("failures", "errors")), "ordinary suite counters contain failures/errors")
        cases = list(root.iter("testcase"))
        require(cases and all(not any(c.find(k) is not None for k in ("failure", "error"))
                              for c in cases), "ordinary XML has failure/error or no cases")
        for case in cases:
            identity = case.attrib["classname"] + "#" + case.attrib["name"]
            ordinary.append(identity)
            if case.find("skipped") is not None:
                skipped.add(identity)
    require(len(ordinary) == len(set(ordinary)), "duplicate ordinary cases")
    require(skipped == allowed_skips, "ordinary skips differ from explicit coordinator review")
    require(release["required_ordinary_cases"] and
            set(release["required_ordinary_cases"]).issubset(set(ordinary) - skipped),
            "required ordinary case missing or skipped")
    for key, package in PACKAGES.items():
        artifact = release["apks"][key]
        require(digest(artifact["path"]) == artifact["sha256"], f"{key} APK hash mismatch")
        _, cert = commands.run("verify-" + key, [release["apksigner"], "verify", "--print-certs", artifact["path"]])
        match = re.search(rb"Signer #1 certificate SHA-256 digest: ([0-9a-f]{64})", cert)
        require(match and match.group(1).decode() == CERT and b"Signer #2" not in cert,
                f"{key} signer mismatch")
        _, badging = commands.run("badging-" + key, [release["aapt2"], "dump", "badging", artifact["path"]])
        require(re.search(rb"package: name='" + package.encode() + rb"'", badging), f"{key} package mismatch")
        if key == "app":
            version = re.search(rb"package:.*versionCode='([0-9]+)'", badging)
            require(version and int(version.group(1)) >= 1, "app versionCode below installed code1")
            require(re.search(rb"native-code:.*'arm64-v8a'", badging), "app has no declared arm64-v8a native support")
    require(digest(release["model_path"]) == MODEL and Path(release["model_path"]).stat().st_size == 1590475744,
            "public Qwen model mismatch")
    require(digest(release["fixture_path"]) == FIXTURE, "four-case fixture mismatch")
    cases = [json.loads(line) for line in Path(release["fixture_path"]).read_text().splitlines()]
    require(len(cases) == 4 and len({c["case_id"] for c in cases}) == 4 and all("gold" not in c for c in cases),
            "unexpected fixture inventory")
    require(digest(release["tokenizer_overlay_pins"]) == release["tokenizer_overlay_sha256"], "overlay mismatch")
    require(release["model_license_observation"] ==
            "base Qwen Research License; distributor card apache-2.0; discrepancy unresolved, no eligibility conclusion",
            "model license observation changed or omitted")
    require(release["model_upstream"]["revision"] == "574cf57acf9ca2a56ec7e62e3bd974a413881745" and
            release["model_upstream"]["sha256"] == MODEL, "upstream artifact identity changed or omitted")
    return cases, ordinary


class Fold:
    def __init__(self, release, commands):
        self.r, self.c = release, commands
        self.prefix = [release["adb"], "-s", SERIAL]
        _, data = self.c.run("devices", [release["adb"], "devices", "-l"])
        lines = [line for line in data.decode().splitlines() if line.strip() and not line.startswith("List of devices")]
        require(len(lines) == 1 and lines[0].split()[:2] == [SERIAL, "device"], "not exactly one authorized Fold")
        _, model = self.shell("identity", "getprop", "ro.product.model")
        require(model.strip() == b"Pixel 9 Pro Fold", "wrong device model")

    def shell(self, name, *args, transient=False, **kwargs):
        # adb's remote command is shell text; preserve every argument explicitly.
        runner = self.c.capture if transient else self.c.run
        return runner(name, self.prefix + ["shell", "-T", shlex.join(args)], **kwargs)

    def apk(self, package, label, required=True):
        code, data = self.shell(label + "-paths", "pm", "path", package, allowed=(0, 1))
        paths = data.decode().splitlines()
        if not paths and not required:
            return None
        require(code == 0 and len(paths) == 1, "missing or split APK refused")
        match = re.fullmatch(r"package:(/data/app/(?:[A-Za-z0-9_+=.~\-]+/)+base\.apk)", paths[0])
        require(match, "unexpected installed APK path")
        output = self.c.output / (label + "-installed.apk")
        self.c.run(label + "-bytes", self.prefix + ["exec-out", "cat", match.group(1)],
                   timeout=90, binary_to=output)
        return dict(path=str(output), sha256=digest(output))

    def install(self, key):
        artifact, package = self.r["apks"][key], PACKAGES[key]
        require(digest(artifact["path"]) == artifact["sha256"], "APK changed after host validation")
        old = self.apk(package, "before-" + key, required=False)
        if key == "app":
            require(old and old["sha256"] == self.r["expected_installed_app_sha256"],
                    "installed app changed since release; preserved and stop")
        _, response = self.c.run("install-" + key, self.prefix + ["install", "-r", artifact["path"]], timeout=180)
        require(b"Success" in response, "install did not report Success")
        installed = self.apk(package, "after-" + key)
        require(installed["sha256"] == artifact["sha256"], "installed APK bytes mismatch")
        require(digest(artifact["path"]) == artifact["sha256"], "APK changed during install")
        return installed

    def component(self, package, component):
        _, text = self.shell("instrumentation-registration", "pm", "list", "instrumentation", package)
        expected = f"instrumentation:{component} (target={package})"
        require(expected in text.decode().splitlines(), "exact instrumentation component/target mismatch")

    def stage(self, package, relative, source, immutable=False):
        require(package in PACKAGES.values(), "unapproved package")
        require(re.fullmatch(r"(?:models/[a-f0-9]{64}/model\.gguf|input/[A-Za-z0-9_-]+\.(?:json|jsonl))", relative),
                "unapproved benchmark path")
        root = f"/data/user/0/{package}/files/synthetic-benchmark"
        destination = root + "/" + relative
        parent = str(Path(destination).parent)
        # Test only exact allowlisted benchmark directories; never list owner storage.
        for directory in [root, root + "/" + relative.split("/")[0], parent]:
            self.shell("no-symlink", "run-as", package, "test", "!", "-L", directory)
        self.shell("file-not-symlink", "run-as", package, "test", "!", "-L", destination)
        code, _ = self.shell("exists", "run-as", package, "test", "-e", destination, allowed=(0, 1))
        expected = digest(source)
        if immutable:
            require(expected == MODEL, "model changed after host validation")
        if code == 0:
            require(immutable, "input path exists; never overwrite or retry run ID")
        else:
            self.shell("make-benchmark-dir", "run-as", package, "mkdir", "-p", parent)
            with Path(source).open("rb") as stream:
                # POSIX noclobber uses exclusive creation, including a race after test -e.
                # stdin is binary and the remote shell never parses model/file contents.
                remote = shlex.join(["run-as", package, "sh", "-c", 'set -C; cat > "$1"',
                                     "synthetic-stage", destination])
                self.c.run("stage-public-file", self.prefix + ["shell", "-T", remote],
                           stdin=stream, timeout=180)
        _, value = self.shell("staged-sha256", "run-as", package, "sha256sum", destination, timeout=120)
        require(value.decode().split()[0] == expected, "staged file mismatch; retained unchanged")
        if immutable:
            self.shell("seal-model-file", "run-as", package, "chmod", "0400", destination)
            self.shell("seal-model-dir", "run-as", package, "chmod", "0500", parent)
        return destination

    def stop_and_verify(self, package, component):
        self.shell("stop-exact-test-target", "am", "force-stop", package, timeout=10)
        names = [package] + (["app.skein:inference", "app.skein.test"] if package == "app.skein" else [])
        absent = False
        consecutive_absent = 0
        for attempt in range(4):
            code, data = self.shell("target-pids-" + str(attempt), "pidof", *names, allowed=(0, 1), timeout=3)
            absent = code == 1 and not data.strip()
            consecutive_absent = consecutive_absent + 1 if absent else 0
            if consecutive_absent >= 2:
                break
            time.sleep(0.5)
        require(consecutive_absent >= 2,
                "remote test stop not proven; no later device workload permitted")
        code, activity, stderr = self.shell("active-instrumentation", "dumpsys", "activity", "-p", package,
                                           "processes", package, timeout=5, transient=True)
        lines = activity.rstrip().splitlines()
        header_valid = bool(lines and lines[0] == b"ACTIVITY MANAGER RUNNING PROCESSES (dumpsys activity processes)")
        footer_valid = bool(lines and re.fullmatch(rb"  mForceBackgroundCheck=(?:true|false)", lines[-1]))
        errors = [category for category, pattern in (
            ("bad_command", rb"bad activity command|unknown command"),
            ("permission_denied", rb"permission deni(?:al|ed)"),
            ("timeout", rb"dump timeout|timed out"),
            ("error", rb"error:|error dumping service|exception"),
        ) if re.search(pattern, activity + b"\n" + stderr, re.I)]
        if stderr:
            errors.append("stderr_nonempty")
        if code == 124:
            errors.append("command_timeout")
        elif code != 0:
            errors.append("command_exit_failure")
        active = b"active instrumentation:" in activity.lower()
        save(self.c.output / "active-instrumentation-proof.json", dict(
            command_succeeded=code == 0, exit_code=code, header_valid=header_valid, footer_valid=footer_valid,
            error_categories=errors, active_instrumentation_present=active,
            consecutive_absent_pid_checks=consecutive_absent, exact_processes_absent=names,
            stdout_bytes=len(activity), stdout_sha256=hashlib.sha256(activity).hexdigest(),
            stderr_bytes=len(stderr), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
            raw_output_retained=False))
        require(code == 0, "cannot verify active instrumentation state: query failed")
        require(header_valid and footer_valid,
                "cannot verify active instrumentation state: incomplete process dump")
        require(not errors,
                "cannot verify active instrumentation state")
        require(not active,
                "remote test stop not proven; no later device workload permitted")
        return dict(force_stopped=package, exact_processes_absent=names, active_instrumentation_absent=True)

    def instrument(self, phase, arguments):
        package, component, selector = PHASES[phase]
        self.component(package, component)
        argv = self.prefix + ["shell", "am", "instrument", "-w", "-r", "-e", "class", selector,
                              "-e", "synthetic_enabled", "true"]
        for key, value in arguments.items():
            argv += ["-e", key, value]
        argv.append(component)
        started = time.monotonic()
        record = dict(argv=argv, selector=selector, timeout_seconds=900, host_timeout=False,
                      remote_stop_verified=False)
        log = self.c.output / "instrumentation.log"
        with log.open("xb") as stream, (self.c.output / "instrumentation.stderr").open("xb") as errors:
            proc = subprocess.Popen(argv, stdout=stream, stderr=errors)
            try:
                record["exit_code"] = proc.wait(timeout=900)
            except subprocess.TimeoutExpired:
                record.update(host_timeout=True, exit_code=124)
            except KeyboardInterrupt:
                record.update(host_interrupted=True, exit_code=130)
            finally:
                # Stop the Android workload BEFORE reaping a timed-out host adb process.
                try:
                    record["remote_cleanup"] = self.stop_and_verify(package, component)
                    record["remote_stop_verified"] = True
                except Exception as error:
                    record["remote_cleanup_error"] = str(error)
                if proc.poll() is None:
                    try:
                        proc.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.wait(timeout=10)
                record["elapsed_seconds"] = round(time.monotonic() - started, 3)
                save(self.c.output / "instrumentation-summary.json", record)
        text = log.read_bytes()
        class_name, method_name = selector.split("#")
        record["junit_passed"] = (record.get("exit_code") == 0 and
            bool(re.search(rb"OK \(1 test\)", text)) and b"INSTRUMENTATION_CODE: -1" in text and
            ("INSTRUMENTATION_STATUS: class=" + class_name).encode() in text and
            ("INSTRUMENTATION_STATUS: test=" + method_name).encode() in text)
        save(self.c.output / "instrumentation-summary.json", record)
        return record

    def collect(self, package, run_id, names):
        paths = {}
        for name in names:
            remote = f"/data/user/0/{package}/files/synthetic-benchmark/output/{run_id}/{name}"
            local = self.c.output / name
            try:
                self.c.run("collect-" + name, self.prefix + ["exec-out", "run-as", package, "cat", remote],
                           timeout=30, binary_to=local)
                _, value = self.shell("output-sha256", "run-as", package, "sha256sum", remote)
                require(value.decode().split()[0] == digest(local), "collected result hash mismatch")
                paths[name] = str(local)
            except Exception as error:
                # A partial cat remains as-is; failed/missing output is never manufactured.
                save(self.c.output / (name + ".collection-error.json"), {"error": str(error)})
        return paths


def verify_parity(report, run_id):
    require(report["run_id"] == run_id and report["model_sha256"] == MODEL and
            report["model_size"] == 1590475744 and report["template_sha256"] == TEMPLATE, "parity identity mismatch")
    expected = {"empty-system", "role-word", "unicode-whitespace", "repeated-turns", "literal-control-isolation"}
    rows = report["cases"]
    require(len(rows) == 5 and {r["case_id"] for r in rows} == expected and
            all(r["status"] == "ok" for r in rows), "parity case inventory/status failure")
    for row in rows:
        if row["case_id"] == "literal-control-isolation":
            token = row["control_token_id"]
            require(row["actual_ids"].count(token) == row["unsafe_reference_ids"].count(token) - 1,
                    "literal control count mismatch")
        else:
            require(row["native_render_equal"] and row["actual_ids"] == row["reference_ids"], "native ID mismatch")


def verify_answers(manifest, rows, release, cases, run_id):
    expected = dict(run_id=run_id, build_sha=release["source_sha"], model_sha256=MODEL,
                    template_sha256=TEMPLATE, fixture_sha256=FIXTURE, case_set_sha256=CASE_SET,
                    llama_sha=release["llama_sha"], tokenizer_overlay_sha256=release["tokenizer_overlay_sha256"],
                    apk_sha256=release["apks"]["app"]["sha256"], test_apk_sha256=release["apks"]["app_test"]["sha256"])
    require(all(manifest.get(k) == v for k, v in expected.items()), "answer manifest identity mismatch")
    if release.get("test_only_update"):
        require(manifest.get("test_build_sha") == release["test_build_sha"] and
                manifest.get("test_build_sha_provenance") ==
                "declared host opt-in test source; installed test APK digest measured" and
                manifest.get("model_blake3") == MODEL_BLAKE3 and
                manifest.get("model_blake3_provenance") == "host_declared_bound_to_device_sha256" and
                manifest.get("host_model_identity_evidence_sha256") == HOST_IDENTITY,
                "answer test-source/host-model provenance mismatch")
    require(manifest["sampling"] == SAMPLING and manifest["seeds"] == [17] and manifest["threads"] == 4
            and manifest["case_timeout_ms"] == 180000 and manifest["context"]["requested"] == 4096
            and 0 < manifest["context"]["allocated"] <= 4096, "runtime profile mismatch")
    require(len(rows) == 4 and {(r["case_id"], r["seed"]) for r in rows} == {(c["case_id"], 17) for c in cases},
            "answer case/seed missing or duplicated")
    for row in rows:
        require(row["status"] == "ok" and row["used_sources_status"] == "finalized_prompt", "incomplete/runtime failure row")
        if not row["generation_skipped"]:
            gen, measure = row["generation"], row["measurement"]
            require(gen and measure and gen["isolated_count_consistency"] and
                    gen["prompt_tokens"] == measure["prompt_tokens"] and measure["model_sha256"] == MODEL,
                    "prompt count/model inconsistency")
            require(0 < gen["generated_tokens"] <= 256 and gen["stop_reason"] in ("EOS", "LENGTH"),
                    "unexpected stop/count; retain for review")
    require(any(not r["generation_skipped"] for r in rows), "generation not exercised")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", required=True, help="coordinator-filled immutable candidate JSON")
    parser.add_argument("--phase", choices=PHASES, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--execute", action="store_true", help="requires released candidate and exact scope; mutates only declared packages")
    parser.add_argument("--parity-summary", help="required before answers; successful prior same-release parity summary")
    args = parser.parse_args()
    require(re.fullmatch(r"[A-Za-z0-9_-]{1,90}", args.run_id), "unsafe run ID")
    output = Path(args.output).resolve()
    allowed = Path("/Users/andrewherrera/skein-worktrees/conference-demo-20260929/build/agent-logs/fold").resolve()
    require(output.is_relative_to(allowed), "output must remain under this runner's ignored fold logs")
    output.mkdir(parents=True, exist_ok=False)
    commands = Commands(output)
    release = json.loads(Path(args.release).read_text())
    os.environ["JAVA_HOME"] = "/opt/homebrew/Cellar/openjdk@17/17.0.20.1/libexec/openjdk.jdk/Contents/Home"
    summary = dict(phase=args.phase, run_id=args.run_id, source_sha=release.get("source_sha"),
                   release_sha256=digest(args.release), executed=False, complete=False, quality_assessed=False,
                   scope="native five-case parity" if args.phase == "parity" else "supplied evidence; no retrieval/owner-model/UI proof")
    if release.get("test_only_update"):
        summary.update(test_build_sha=release.get("test_build_sha"), test_only_update=True,
                       production_app_action="verify installed bytes only")
    save(output / "release-snapshot.json", release)
    try:
        cases, ordinary = validate(release, commands)
        summary["ordinary_case_count"] = len(ordinary)
        summary["ordinary_skipped_cases"] = release.get("allowed_ordinary_skips", [])
        summary["ordinary_executed_passes"] = len(ordinary) - len(summary["ordinary_skipped_cases"])
        if args.phase == "answers":
            require(args.parity_summary, "answer phase requires reviewed prior parity summary")
            if release.get("test_only_update"):
                summary["parity_reuse"] = verify_parity_reuse(release, args.parity_summary)
            else:
                previous = json.loads(Path(args.parity_summary).read_text())
                require(previous["complete"] and previous["executed"] and previous["phase"] == "parity" and
                        previous["release_sha256"] == summary["release_sha256"], "prior same-release parity not passed")
        require(not release.get("test_only_update") or args.phase == "answers",
                "test-only release authorizes answer phase only")
        if not args.execute:
            summary["host_validation_passed"] = True
            return
        coordination = Path("/Users/andrewherrera/skein-session-coordination/20260929")
        lease = json.loads((coordination / "device.lock/owner.json").read_text())
        require(lease["agent"] == "/root/fts_verification" and
                lease["token"] == "conference-demo-fold-20260929" and
                lease["authorization"]["status"] == "RELEASED_FOR_UPDATE_AND_DEMO_CHECKS",
                "physical runner lease/authorization changed")
        fold = Fold(release, commands)
        summary["executed"] = True
        summary["installed_apks"] = install_for_phase(fold, args.phase)
        package = PHASES[args.phase][0]
        root = f"/data/user/0/{package}/files/synthetic-benchmark"
        model = fold.stage(package, f"models/{MODEL}/model.gguf", release["model_path"], immutable=True)
        fold.shell("fresh-output", "run-as", package, "test", "!", "-e", root + "/output/" + args.run_id)
        if args.phase == "parity":
            arguments = dict(synthetic_model_file=model, synthetic_model_sha256=MODEL, synthetic_run_id=args.run_id)
            names = ("native-parity.json",)
        else:
            prepared = output / "prepared"
            sampling = output / "sampling.json"
            save(sampling, SAMPLING)
            commands.run("prepare", [sys.executable, release["preparation_helper"], "--model", release["model_path"],
                "--model-sha256", MODEL, "--model-license", release["model_license_observation"],
                "--apk", release["apks"]["app"]["path"],
                "--fixture", release["fixture_path"], "--case-set-sha256", CASE_SET, "--build-sha", release["source_sha"],
                "--llama-sha", release["llama_sha"], "--tokenizer-overlay-sha256", release["tokenizer_overlay_sha256"],
                "--run-id", args.run_id, "--output-dir", str(prepared), "--device-root", root,
                "--context-length", "4096", "--threads", "4", "--seeds", "17", "--case-timeout-ms", "180000",
                "--sampling", str(sampling)], timeout=120)
            if release.get("test_only_update"):
                require(digest(release["preparation_helper"]) == release["preparation_helper_sha256"],
                        "preparation helper changed during preparation")
                inject_test_metadata(release, prepared / "config.json")
            fold.stage(package, f"input/{args.run_id}.jsonl", prepared / "input.jsonl")
            config = fold.stage(package, f"input/{args.run_id}.json", prepared / "config.json")
            arguments = dict(synthetic_config=config)
            names = ("setup-progress.jsonl", "run_manifest.json", "answers.jsonl") if release.get("test_only_update") else ("run_manifest.json", "answers.jsonl")
        result = fold.instrument(args.phase, arguments)
        summary["instrumentation"] = result
        paths = fold.collect(package, args.run_id, names)
        summary["collected"] = paths
        if release.get("test_only_update"):
            progress = review_setup_progress(output / "setup-progress.jsonl", args.run_id,
                                             "setup-progress.jsonl" in paths)
            summary["setup_progress"] = progress
            save(output / "setup-progress-review.json", progress)
        require(not result["host_timeout"] and result["remote_stop_verified"] and result["junit_passed"],
                "phase execution/stop failure; do not start next workload")
        require(set(paths) == set(names), "missing complete result artifacts")
        if release.get("test_only_update"):
            require(progress["format_valid"], "setup progress malformed; original bytes retained")
        if args.phase == "parity":
            verify_parity(json.loads(Path(paths["native-parity.json"]).read_text()), args.run_id)
        else:
            rows = [json.loads(line) for line in Path(paths["answers.jsonl"]).read_text().splitlines()]
            verify_answers(json.loads(Path(paths["run_manifest.json"]).read_text()), rows, release, cases, args.run_id)
            summary["row_review"] = [{k: row[k] for k in ("case_id", "seed", "status", "generation_skipped", "generation")}
                                     for row in rows]
        summary["complete"] = True
    except BaseException as error:
        summary["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        save(output / "summary.json", summary)


if __name__ == "__main__":
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f"signal {signum}; exact workload cleanup required")
    signal.signal(signal.SIGTERM, interrupted)
    main()
