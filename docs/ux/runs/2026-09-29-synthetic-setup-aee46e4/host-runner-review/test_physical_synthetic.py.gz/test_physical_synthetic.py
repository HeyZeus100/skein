"""Host-only safety checks. All Android subprocesses are mocked."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace

SPEC = importlib.util.spec_from_file_location("physical_synthetic", Path(__file__).with_name("physical_synthetic.py"))
m = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(m)
FIXTURES = Path(__file__).parent.parent / "physical-runner-preparation-v2/fixtures"


class SafetyTests(unittest.TestCase):
    def native_eog_fixture(self):
        return dict(scope="classification-only", generated_stop_behavior="unmeasured",
            declared_eos=dict(token_id=151645, is_eog=True),
            controls=[dict(spelling=spelling, token_ids=[token], singleton=True,
                classifications=[dict(token_id=token, is_eog=True)]) for spelling, token in
                [("<|im_end|>", 151645), ("<|endoftext|>", 151643), ("</s>", 128247)]])

    def release_fixture(self, directory):
        root = Path(directory)
        helper = root / "prepare.py"
        helper.write_text("# host mock helper\n")
        identity = root / "identity.json"
        m.save(identity, dict(status="COMPLETE_HOST_PUBLIC_MODEL_IDENTITY", timed_out=False,
            model_stat_unchanged=True, candidate_source_sha=m.APP_SOURCE,
            model=dict(event="complete", bytes=1590475744, sha256=m.MODEL, blake3=m.MODEL_BLAKE3)))
        scope = root / "scope.json"
        m.save(scope, dict(approved=True, production_app_unchanged=True, native_test_unchanged=True,
            app_source_sha=m.APP_SOURCE, test_build_sha="a" * 40,
            changed_paths=["app/src/syntheticBenchmark/kotlin/app/skein/benchmark/SyntheticAnswerBenchmarkTest.kt"]))
        release = dict(test_only_update=True, source_sha=m.APP_SOURCE, ordinary_source_sha=m.APP_SOURCE,
            test_build_sha="a" * 40, expected_installed_app_sha256=m.APP_APK,
            apks={"app": {"sha256": m.APP_APK}, "app_test": {"sha256": "b" * 64},
                  "native_test": {"sha256": m.NATIVE_APK}},
            preparation_helper=str(helper), preparation_helper_sha256=m.digest(helper),
            test_only_source_review=dict(path=str(scope), sha256=m.digest(scope)),
            host_model_identity=dict(path=str(identity), sha256=m.digest(identity)),
            parity_reuse=dict(approved=True), llama_sha="c" * 40, tokenizer_overlay_sha256="d" * 64)
        return release

    def parity_reuse_fixture(self, root, release):
        root = Path(root)
        report_path = root / "parity-report.json"
        m.save(report_path, dict(run_id="prior", model_sha256=m.MODEL, model_size=1590475744,
            template_sha256=m.TEMPLATE, native_eog=self.native_eog_fixture(),
            cases=[dict(case_id=i, status="ok", native_render_equal=True,
            actual_ids=[1, 2], reference_ids=[1, 2]) for i in
            ["empty-system", "role-word", "unicode-whitespace", "repeated-turns"]] +
            [dict(case_id="literal-control-isolation", status="ok", actual_ids=[1],
                  unsafe_reference_ids=[1, 1], control_token_id=1)]))
        old_release = root / "prior-release.json"
        m.save(old_release, dict(authorization="RELEASED_FOR_PHYSICAL_SYNTHETIC", source_sha=m.APP_SOURCE,
            apks={"app": {"sha256": m.APP_APK}, "native_test": {"sha256": m.NATIVE_APK}},
            llama_sha=release["llama_sha"],
            tokenizer_overlay_sha256=release["tokenizer_overlay_sha256"]))
        summary = root / "prior-summary.json"
        m.save(summary, dict(complete=True, executed=True, phase="parity", source_sha=m.APP_SOURCE,
            run_id="prior", release_sha256=m.digest(old_release),
            installed_apks={"native_test": {"sha256": m.NATIVE_APK}},
            collected={"native-parity.json": str(report_path)}, instrumentation=dict(remote_stop_verified=True,
            junit_passed=True, exit_code=0, host_timeout=False)))
        release["parity_reuse"] = dict(approved=True, summary=dict(path=str(summary), sha256=m.digest(summary)),
            report=dict(path=str(report_path), sha256=m.digest(report_path)),
            release=dict(path=str(old_release), sha256=m.digest(old_release)))
        return summary

    def test_legacy_released_manifest_is_rejected_before_any_command(self):
        calls = []
        class NoCommands:
            def run(self, *args, **kwargs):
                calls.append(args)
                raise AssertionError("legacy release reached a command")
        with self.assertRaisesRegex(ValueError, "explicit test-only policy"):
            m.validate(dict(authorization="RELEASED_FOR_PHYSICAL_SYNTHETIC", source_sha=m.APP_SOURCE), NoCommands())
        self.assertEqual(calls, [])
        def unexpected(*args):
            calls.append(args)
            raise AssertionError("legacy or parity install policy reached device")
        for policy, phase in (({}, "answers"), ({}, "parity"), ({"test_only_update": True}, "parity")):
            fold = SimpleNamespace(r=policy, apk=unexpected, install=unexpected)
            with self.subTest(policy=policy, phase=phase), self.assertRaises(ValueError):
                m.install_for_phase(fold, phase)
        self.assertEqual(calls, [])

    def test_parity_reuse_rejects_missing_or_changed_prior_released_app(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            for missing in (True, False):
                release = self.release_fixture(directory)
                summary = self.parity_reuse_fixture(directory, release)
                rec = release["parity_reuse"]["release"]
                path = Path(rec["path"]);old = json.loads(path.read_text())
                if missing:del old["apks"]["app"]
                else:old["apks"]["app"]["sha256"] = "0" * 64
                m.save(path, old);rec["sha256"] = m.digest(path)
                data = json.loads(summary.read_text());data["release_sha256"] = rec["sha256"]
                m.save(summary, data);release["parity_reuse"]["summary"]["sha256"] = m.digest(summary)
                with self.subTest(missing=missing), self.assertRaisesRegex(ValueError, "prior released app"):
                    m.verify_parity_reuse(release, summary)

    def test_parity_reuse_rejects_missing_or_malformed_eog_classification_facts(self):
        mutations = {
            "missing": lambda report: report.pop("native_eog"),
            "wrong_scope": lambda report: report["native_eog"].update(scope="generation"),
            "generated_stop_claim": lambda report: report["native_eog"].update(generated_stop_behavior="EOS"),
            "declared_id": lambda report: report["native_eog"]["declared_eos"].update(token_id=151643),
            "declared_false": lambda report: report["native_eog"]["declared_eos"].update(is_eog=False),
            "declared_numeric_true": lambda report: report["native_eog"]["declared_eos"].update(is_eog=1),
            "missing_control": lambda report: report["native_eog"]["controls"].pop(),
            "unknown_spelling": lambda report: report["native_eog"]["controls"][0].update(spelling="unknown"),
            "duplicate_control": lambda report: report["native_eog"]["controls"].__setitem__(
                2, copy.deepcopy(report["native_eog"]["controls"][0])),
            "wrong_token_ids": lambda report: report["native_eog"]["controls"][0].update(token_ids=[0]),
            "nonsingleton": lambda report: report["native_eog"]["controls"][0].update(singleton=False),
            "multiple_ids": lambda report: report["native_eog"]["controls"][0].update(token_ids=[151645, 1]),
            "classification_missing": lambda report: report["native_eog"]["controls"][0].update(classifications=[]),
            "classification_wrong_id": lambda report: report["native_eog"]["controls"][0]["classifications"][0].update(token_id=1),
            "classification_false": lambda report: report["native_eog"]["controls"][2]["classifications"][0].update(is_eog=False),
        }
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            for name, mutation in mutations.items():
                release = self.release_fixture(directory);summary = self.parity_reuse_fixture(directory, release)
                record = release["parity_reuse"]["report"];path = Path(record["path"])
                report = json.loads(path.read_text());mutation(report)
                m.save(path, report);record["sha256"] = m.digest(path)
                with self.subTest(mutation=name), self.assertRaisesRegex(ValueError, "native .*EOG|native declared EOS"):
                    m.verify_parity_reuse(release, summary)

    def test_changed_test_source_keeps_production_identity_and_fresh_config(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            release = self.release_fixture(directory)
            with patch.object(m, "HOST_IDENTITY", release["host_model_identity"]["sha256"]):
                m.validate_test_only_release(release)
                config = Path(directory) / "config.json"
                m.save(config, dict(build_sha=m.APP_SOURCE, expected_apk_sha256=m.APP_APK,
                                    model_sha256=m.MODEL, model_size=1590475744))
                m.inject_test_metadata(release, config)
                result = json.loads(config.read_text())
                self.assertEqual(result["build_sha"], m.APP_SOURCE)
                self.assertEqual(result["test_build_sha"], release["test_build_sha"])
                self.assertEqual(set(result["host_model_identity"]),
                    {"schema_version", "model_sha256", "model_size", "blake3", "evidence_sha256"})
                with self.assertRaisesRegex(ValueError, "never overwrite"):
                    m.inject_test_metadata(release, config)

    def test_test_only_policy_rejects_changed_production_native_and_unreviewed_scope(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            release = self.release_fixture(directory)
            with patch.object(m, "HOST_IDENTITY", release["host_model_identity"]["sha256"]):
                for field, value in [("source_sha", "e" * 40), ("ordinary_source_sha", "e" * 40),
                                     ("test_build_sha", m.APP_SOURCE), ("test_only_update", False),
                                     ("expected_installed_app_sha256", "e" * 64)]:
                    bad = copy.deepcopy(release);bad[field] = value
                    with self.subTest(field=field), self.assertRaises(ValueError):
                        m.validate_test_only_release(bad)
                bad = copy.deepcopy(release);bad["apks"]["native_test"]["sha256"] = "e" * 64
                with self.assertRaisesRegex(ValueError, "changed native"):
                    m.validate_test_only_release(bad)
                scope = Path(release["test_only_source_review"]["path"])
                changed = json.loads(scope.read_text());changed["changed_paths"] = sorted(m.TEST_ONLY_PATHS)
                m.save(scope, changed);release["test_only_source_review"]["sha256"] = m.digest(scope)
                m.validate_test_only_release(release)
                for invalid_path in ("app/src/main/Unsafe.kt", "app/src/test/OrdinaryTest.kt"):
                    changed["changed_paths"] = [invalid_path]
                    m.save(scope, changed);release["test_only_source_review"]["sha256"] = m.digest(scope)
                    with self.subTest(path=invalid_path), self.assertRaisesRegex(ValueError, "non-test"):
                        m.validate_test_only_release(release)

    def test_host_identity_wrong_hash_or_model_binding_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            release = self.release_fixture(directory)
            with patch.object(m, "HOST_IDENTITY", release["host_model_identity"]["sha256"]):
                path = Path(release["host_model_identity"]["path"])
                path.write_text(path.read_text() + " ")
                with self.assertRaisesRegex(ValueError, "hash mismatch"):
                    m.host_model_identity(release)
            data = json.loads(path.read_text());data["model"]["sha256"] = "0" * 64;m.save(path,data)
            release["host_model_identity"]["sha256"] = m.digest(path)
            with patch.object(m, "HOST_IDENTITY", m.digest(path)), self.assertRaisesRegex(ValueError, "binding mismatch"):
                m.host_model_identity(release)

    def test_explicit_cross_release_parity_reuse_preserves_native_identity_scope(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            release = self.release_fixture(directory);summary = self.parity_reuse_fixture(directory, release)
            result = m.verify_parity_reuse(release, summary)
            self.assertTrue(result["approved"])
            self.assertIn("generated stopping unmeasured", result["scope"])
            self.assertEqual(result["native_apk_sha256"], m.NATIVE_APK)
            self.assertNotEqual(release["test_build_sha"], m.APP_SOURCE)

    def test_parity_reuse_rejects_changed_native_model_template_and_pins(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            for mutation in ("native", "model", "template", "llama", "overlay"):
                release = self.release_fixture(directory);summary = self.parity_reuse_fixture(directory, release)
                if mutation == "native":release["apks"]["native_test"]["sha256"] = "0" * 64
                elif mutation == "llama":release["llama_sha"] = "0" * 40
                elif mutation == "overlay":release["tokenizer_overlay_sha256"] = "0" * 64
                else:
                    record=release["parity_reuse"]["report"];path=Path(record["path"]);data=json.loads(path.read_text())
                    data["model_sha256" if mutation=="model" else "template_sha256"]="0"*64
                    m.save(path,data);record["sha256"]=m.digest(path)
                with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                    m.verify_parity_reuse(release,summary)

    def test_parity_reuse_rejects_stale_rejected_incomplete_or_missing_approval(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            for mutation in ("stale", "rejected_release", "incomplete", "stop", "junit", "approval", "changed_bytes"):
                release=self.release_fixture(directory);summary=self.parity_reuse_fixture(directory,release)
                data=json.loads(summary.read_text())
                if mutation=="approval":release["parity_reuse"]["approved"]=False
                elif mutation=="rejected_release":
                    rec=release["parity_reuse"]["release"];path=Path(rec["path"]);old=json.loads(path.read_text())
                    old["authorization"]="NOT_RELEASED";m.save(path,old);rec["sha256"]=m.digest(path)
                    data["release_sha256"]=rec["sha256"]
                elif mutation=="stale":data["release_sha256"]="0"*64
                elif mutation=="incomplete":data["complete"]=False
                elif mutation=="stop":data["instrumentation"]["remote_stop_verified"]=False
                elif mutation=="junit":data["instrumentation"]["junit_passed"]=False
                m.save(summary,data)
                if mutation!="changed_bytes":release["parity_reuse"]["summary"]["sha256"]=m.digest(summary)
                else:summary.write_text(summary.read_text()+" ")
                with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                    m.verify_parity_reuse(release,summary)

    def test_test_only_update_never_installs_when_current_app_mismatches(self):
        calls=[]
        fold=SimpleNamespace(r=dict(test_only_update=True,expected_installed_app_sha256=m.APP_APK),
            apk=lambda *args:dict(sha256="0"*64),install=lambda key:calls.append(key))
        with self.assertRaisesRegex(ValueError,"before any install"):m.install_for_phase(fold,"answers")
        self.assertEqual(calls,[])
        fold.apk=lambda *args:dict(sha256=m.APP_APK)
        m.install_for_phase(fold,"answers")
        self.assertEqual(calls,["app_test"])

    def test_progress_collection_failure_keeps_partial_and_separate_error(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            output=Path(directory);calls=[]
            def run(name,argv,**kwargs):
                calls.append(name);kwargs["binary_to"].write_bytes(b'{"partial":')
                raise ValueError("mock transport failure")
            fold=m.Fold.__new__(m.Fold);fold.prefix=["adb","-s",m.SERIAL]
            fold.c=SimpleNamespace(output=output,run=run)
            paths=fold.collect("app.skein","test",("setup-progress.jsonl",))
            self.assertEqual(paths,{})
            self.assertEqual(calls,["collect-setup-progress.jsonl"])
            self.assertEqual((output/"setup-progress.jsonl").read_bytes(),b'{"partial":')
            error=json.loads((output/"setup-progress.jsonl.collection-error.json").read_text())
            self.assertEqual(error["error"],"mock transport failure")
            review=m.review_setup_progress(output/"setup-progress.jsonl","test",False)
            self.assertFalse(review["format_valid"])
            self.assertFalse(review["setup_success_claimed"])

    def test_progress_is_diagnostic_not_completion_and_rejects_truncation_or_wrong_run(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            path=Path(directory)/"setup-progress.jsonl"
            row=dict(schema_version=1,run_id="test",sequence=0,phase="session_unlock",event="start",
                     elapsed_ms=4,bytes_processed=None,total_bytes=None,error_code=None)
            path.write_text(json.dumps(row)+"\n")
            review=m.review_setup_progress(path,"test",True)
            self.assertTrue(review["format_valid"])
            self.assertFalse(review["setup_success_claimed"])
            self.assertEqual(review["last"]["phase"],"session_unlock")
            path.write_text(path.read_text()+'{"sequence":')
            self.assertFalse(m.review_setup_progress(path,"test",True)["format_valid"])
            path.write_text(json.dumps(row)+"\n")
            self.assertFalse(m.review_setup_progress(path,"other",True)["format_valid"])

    def check_transient_query_retention(self, payload, stderr=b"", code=0, timeout=False):
        marker = b"UNRELATED_GLOBAL_METADATA_MUST_NOT_BE_RETAINED"
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            output = Path(directory)
            fold = m.Fold.__new__(m.Fold)
            fold.prefix = ["adb", "-s", m.SERIAL]
            fold.c = m.Commands(output)
            def run(argv, stdout, stderr, timeout, **kwargs):
                remote = argv[-1]
                if remote.startswith("dumpsys activity"):
                    self.assertEqual(stdout, subprocess.PIPE)
                    self.assertEqual(stderr, subprocess.PIPE)
                    if query_timeout:
                        raise subprocess.TimeoutExpired(argv, timeout, output=payload, stderr=query_stderr)
                    return SimpleNamespace(returncode=code, stdout=payload, stderr=query_stderr)
                self.assertTrue(remote.startswith("pidof") or remote.startswith("am force-stop"))
                return SimpleNamespace(returncode=1 if remote.startswith("pidof") else 0)
            query_stderr, query_timeout = stderr, timeout
            failure = None
            with patch.object(m.subprocess, "run", run), patch.object(m.time, "sleep"):
                try:
                    fold.stop_and_verify(m.NATIVE, m.PHASES["parity"][1])
                except ValueError as error:
                    failure = str(error)
            proof = json.loads((output / "active-instrumentation-proof.json").read_text())
            self.assertFalse(any(marker in p.read_bytes() for p in output.iterdir()), "raw metadata retained")
            self.assertFalse(any(p.name.endswith(("active-instrumentation.stdout", "active-instrumentation.stderr"))
                                 for p in output.iterdir()), "query created a raw output file")
            self.assertFalse(failure and marker.decode() in failure, "raw metadata leaked through exception")
            self.assertEqual(proof["stdout_bytes"], len(payload))
            self.assertEqual(proof["stdout_sha256"], m.hashlib.sha256(payload).hexdigest())
            self.assertEqual(proof["stderr_bytes"], len(query_stderr))
            self.assertEqual(proof["stderr_sha256"], m.hashlib.sha256(query_stderr).hexdigest())
            self.assertFalse(proof["raw_output_retained"])
            return proof, failure

    def test_scoped_query_success_retains_only_minimized_proof(self):
        body = self.inactive_dump().replace(b"  OOM levels:",
                 b"  UNRELATED_GLOBAL_METADATA_MUST_NOT_BE_RETAINED\n  OOM levels:")
        proof, failure = self.check_transient_query_retention(body)
        self.assertIsNone(failure)
        self.assertTrue(proof["command_succeeded"] and proof["header_valid"] and proof["footer_valid"])
        self.assertFalse(proof["active_instrumentation_present"])
        self.assertEqual(proof["error_categories"], [])

    def test_scoped_query_failure_retains_proof_without_stdout_or_stderr_contents(self):
        marker = b"UNRELATED_GLOBAL_METADATA_MUST_NOT_BE_RETAINED"
        body = self.inactive_dump().replace(b"  OOM levels:", marker + b"\n  OOM levels:")
        active = body.replace(b"  OOM levels:", b"  Active instrumentation:\n  OOM levels:")
        cases = (
            ("active", active, b"", 0, False),
            ("unsupported", b"Unknown command: processes\n" + marker, b"", 0, False),
            ("nonzero", body, b"", 1, False),
            ("timeout", body, b"", 0, True),
            ("stderr", body, b"Permission Denial " + marker, 0, False),
            ("truncated", body[:body.rfind(b"  mForceBackgroundCheck=")], b"", 0, False),
        )
        for name, payload, stderr, code, timeout in cases:
            with self.subTest(case=name):
                proof, failure = self.check_transient_query_retention(payload, stderr, code, timeout)
                self.assertIsNotNone(failure)
                self.assertEqual(proof["exit_code"], 124 if timeout else code)
                if name == "active":
                    self.assertTrue(proof["active_instrumentation_present"])
                if name == "stderr":
                    self.assertIn("permission_denied", proof["error_categories"])
                    self.assertIn("stderr_nonempty", proof["error_categories"])

    def test_other_command_output_capture_is_unchanged(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            output = Path(directory)
            def run(argv, stdout, stderr, **kwargs):
                stdout.write(b"ordinary stdout")
                stderr.write(b"ordinary stderr")
                return SimpleNamespace(returncode=0)
            with patch.object(m.subprocess, "run", run):
                code, data = m.Commands(output).run("ordinary", ["host-mock"])
            self.assertEqual((code, data), (0, b"ordinary stdout"))
            self.assertEqual((output / "001-ordinary.stdout").read_bytes(), b"ordinary stdout")
            self.assertEqual((output / "001-ordinary.stderr").read_bytes(), b"ordinary stderr")

    def mock_stop(self, payload, pids=None, package=None):
        fold = m.Fold.__new__(m.Fold)
        calls = []
        responses = iter(pids or [(1, b"")] * 4)
        def shell(name, *args, **kwargs):
            calls.append((name, args))
            if name.startswith("target-pids"):
                return next(responses)
            if name == "active-instrumentation":
                if isinstance(payload, Exception):
                    raise payload
                return 0, payload, b""
            return 0, b""
        fold.shell = shell
        package = package or m.NATIVE
        component = m.PHASES["parity" if package == m.NATIVE else "answers"][1]
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory, patch.object(m.time, "sleep"):
            fold.c = type("C", (), {"output": Path(directory)})()
            result = fold.stop_and_verify(package, component)
        return result, calls

    def inactive_dump(self):
        return (FIXTURES / "inactive-target-processes.stdout").read_bytes()

    def test_actual_inactive_process_dump_and_two_absent_pids_prove_stop(self):
        result, calls = self.mock_stop(self.inactive_dump())
        self.assertTrue(result["active_instrumentation_absent"])
        self.assertEqual([args for name, args in calls if name.startswith("target-pids")],
                         [("pidof", m.NATIVE)] * 2)
        self.assertEqual(calls[-1], ("active-instrumentation",
                         ("dumpsys", "activity", "-p", m.NATIVE, "processes", m.NATIVE)))

    def test_app_stop_checks_all_three_exact_process_names(self):
        _, calls = self.mock_stop(self.inactive_dump(), package="app.skein")
        self.assertEqual([args for name, args in calls if name.startswith("target-pids")],
                         [("pidof", "app.skein", "app.skein:inference", "app.skein.test")] * 2)
        self.assertEqual(calls[-1][1],
                         ("dumpsys", "activity", "-p", "app.skein", "processes", "app.skein"))

    def test_pid_absence_must_be_consecutive_and_have_exact_exit_and_empty_output(self):
        result, calls = self.mock_stop(self.inactive_dump(),
                                      [(1, b""), (0, b"321\n"), (1, b""), (1, b"")])
        self.assertTrue(result["active_instrumentation_absent"])
        self.assertEqual(sum(name.startswith("target-pids") for name, _ in calls), 4)
        for sequence in ([(1, b""), (0, b"321\n"), (1, b""), (0, b"321\n")],
                         [(0, b"")] * 4, [(1, b"321\n")] * 4):
            with self.subTest(sequence=sequence), self.assertRaisesRegex(ValueError, "stop not proven"):
                self.mock_stop(self.inactive_dump(), sequence)

    def test_active_instrumentation_section_refuses_stop(self):
        body = self.inactive_dump()
        active = body.replace(b"  OOM levels:",
                              b"  Active instrumentation:\n    Instrumentation #0: active\n  OOM levels:")
        with self.assertRaisesRegex(ValueError, "stop not proven"):
            self.mock_stop(active)

    def test_historical_package_mention_does_not_claim_active_instrumentation(self):
        body = self.inactive_dump().replace(b"  mForceBackgroundCheck=",
                b"  pastPackageReason=app.skein.inference.service.test\n  mForceBackgroundCheck=")
        result, _ = self.mock_stop(body)
        self.assertTrue(result["active_instrumentation_absent"])

    def test_bad_unknown_denied_timed_out_or_incomplete_dump_refuses_stop(self):
        body = self.inactive_dump()
        bad = [b"", body.split(b"\n", 1)[1], body[:body.rfind(b"  mForceBackgroundCheck=")],
               (FIXTURES / "unsupported-instrumentation-command.stdout").read_bytes()]
        for error in (b"Bad activity command", b"Unknown command: processes", b"Permission Denial",
                      b"Permission denied", b"DUMP TIMEOUT", b"service timed out", b"Error: failed",
                      b"Error dumping service", b"java.lang.SecurityException"):
            bad.append(body.replace(b"  OOM levels:", error + b"\n  OOM levels:"))
        for index, payload in enumerate(bad):
            with self.subTest(case=index), self.assertRaisesRegex(ValueError, "cannot verify"):
                self.mock_stop(payload)
        with self.assertRaisesRegex(ValueError, "failed with 124"):
            self.mock_stop(ValueError("active-instrumentation failed with 124"))

    def run_mock_instrumentation(self, payload):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            captured = []
            class Process:
                def __init__(self, argv, stdout, stderr):
                    captured.append(argv)
                    stdout.write(payload)
                    stdout.flush()
                def wait(self, timeout):
                    return 0
                def poll(self):
                    return 0
            fold = m.Fold.__new__(m.Fold)
            fold.prefix = ["adb", "-s", m.SERIAL]
            fold.c = type("C", (), {"output": Path(directory)})()
            fold.component = lambda *args: None
            fold.stop_and_verify = lambda *args: {"verified": True}
            with patch.object(m.subprocess, "Popen", Process):
                result = fold.instrument("parity", {"synthetic_run_id": "host_mock"})
            return result, captured[0]

    def test_actual_formatted_success_is_not_reclassified_as_raw_success(self):
        payload = (FIXTURES / "formatted-instrumentation.stdout").read_bytes()
        result, argv = self.run_mock_instrumentation(payload)
        self.assertEqual(argv.count("-r"), 1)
        self.assertFalse(result["junit_passed"])

    def test_raw_status_requires_exact_class_method_and_success_code(self):
        # The formatted body is retained device output. Raw status lines here
        # are explicit mock data, not a claim that the device rerun occurred.
        body = (FIXTURES / "formatted-instrumentation.stdout").read_bytes()
        cls, method = m.PHASES["parity"][2].split("#")
        raw = (f"INSTRUMENTATION_STATUS: class={cls}\n"
               f"INSTRUMENTATION_STATUS: test={method}\n"
               "INSTRUMENTATION_STATUS_CODE: 0\n").encode() + body + b"INSTRUMENTATION_CODE: -1\n"
        result, _ = self.run_mock_instrumentation(raw)
        self.assertTrue(result["junit_passed"])
        for bad in (raw.replace(cls.encode(), b"wrong.Class"),
                    raw.replace(method.encode(), b"wrongMethod"),
                    raw.replace(b"INSTRUMENTATION_CODE: -1", b"INSTRUMENTATION_CODE: 0")):
            with self.subTest(payload=bad):
                result, _ = self.run_mock_instrumentation(bad)
                self.assertFalse(result["junit_passed"])

    def test_unreleased_candidate_stops_before_any_command(self):
        class NoCommands:
            def run(self, *args, **kwargs):
                self.fail("unreleased candidate ran a command")
        with self.assertRaisesRegex(ValueError, "candidate not released"):
            m.validate({"authorization": "NOT_RELEASED"}, NoCommands())

    def test_exact_method_selectors_only(self):
        self.assertEqual(m.PHASES["parity"][2],
                         "app.skein.inference.service.SyntheticTemplateParityTest#publicModelNativeTokenParity")
        self.assertEqual(m.PHASES["answers"][2],
                         "app.skein.benchmark.SyntheticAnswerBenchmarkTest#suppliedEvidenceThroughTheIsolatedApk")

    def test_binary_staging_uses_exclusive_creation_and_preserves_bytes(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            source = Path(directory) / "input.json"
            source.write_bytes(b'\x00\xff\r\n"$()\\')
            seen = []
            class FakeCommands:
                def run(self, name, argv, **kwargs):
                    seen.append((name, argv, kwargs["stdin"].read()))
                    return 0, b""
            fold = m.Fold.__new__(m.Fold)
            fold.prefix, fold.c = ["adb", "-s", m.SERIAL], FakeCommands()
            def shell(name, *args, **kwargs):
                if name == "exists":
                    return 1, b""
                if name == "staged-sha256":
                    return 0, (m.digest(source) + "  path\n").encode()
                return 0, b""
            fold.shell = shell
            path = fold.stage("app.skein", "input/test_run.json", source)
            self.assertTrue(path.endswith("/files/synthetic-benchmark/input/test_run.json"))
            self.assertEqual(seen[0][2], source.read_bytes())
            self.assertIn('set -C; cat > "$1"', seen[0][1][-1])

    def test_existing_input_is_never_overwritten(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            source = Path(directory) / "input.json"
            source.write_bytes(b"{}")
            fold = m.Fold.__new__(m.Fold)
            fold.shell = lambda *args, **kwargs: (0, b"")
            with self.assertRaisesRegex(ValueError, "never overwrite"):
                fold.stage("app.skein", "input/run.json", source)

    def test_lingering_remote_process_refuses_stop_proof(self):
        fold = m.Fold.__new__(m.Fold)
        calls = []
        def shell(name, *args, **kwargs):
            calls.append((name, args))
            return (0, b"12345\n") if name.startswith("target-pids") else (0, b"")
        fold.shell = shell
        with patch.object(m.time, "sleep"), self.assertRaisesRegex(ValueError, "stop not proven"):
            fold.stop_and_verify("app.skein", m.PHASES["answers"][1])
        self.assertEqual(calls[0][1], ("am", "force-stop", "app.skein"))
        self.assertEqual(sum(n.startswith("target-pids") for n, _ in calls), 4)

    def test_timeout_stops_remote_before_reaping_host_and_retains_partial_log(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            output = Path(directory)
            events = []
            class Process:
                returncode = None
                def __init__(self, argv, stdout, stderr):
                    stdout.write(b"partial instrumentation output\n")
                    stdout.flush()
                def wait(self, timeout):
                    events.append(("wait", timeout))
                    if timeout == 900:
                        raise subprocess.TimeoutExpired("adb", timeout)
                    self.returncode = 0
                    return 0
                def poll(self):
                    return self.returncode
                def kill(self):
                    events.append(("kill",))
            fold = m.Fold.__new__(m.Fold)
            fold.prefix = ["adb", "-s", m.SERIAL]
            fold.c = type("C", (), {"output": output})()
            fold.component = lambda *args: None
            def stop(package, component):
                events.append(("remote-stop", package))
                return {"verified": True}
            fold.stop_and_verify = stop
            with patch.object(m.subprocess, "Popen", Process):
                result = fold.instrument("parity", {"synthetic_run_id": "test"})
            self.assertTrue(result["host_timeout"])
            self.assertTrue(result["remote_stop_verified"])
            self.assertFalse(result["junit_passed"])
            self.assertEqual(events[:3], [("wait", 900), ("remote-stop", m.NATIVE), ("wait", 10)])
            self.assertEqual((output / "instrumentation.log").read_bytes(), b"partial instrumentation output\n")
            self.assertEqual(json.loads((output / "instrumentation-summary.json").read_text())["exit_code"], 124)

    def test_parity_status_ok_cannot_hide_changed_actual_token_ids(self):
        ids = ["empty-system", "role-word", "unicode-whitespace", "repeated-turns"]
        report = dict(run_id="test", model_sha256=m.MODEL, model_size=1590475744, template_sha256=m.TEMPLATE,
                      cases=[dict(case_id=i, status="ok", native_render_equal=True, actual_ids=[1, 2],
                                  reference_ids=[1, 2]) for i in ids] + [dict(case_id="literal-control-isolation",
                         status="ok", actual_ids=[1], unsafe_reference_ids=[1, 1], control_token_id=1)])
        m.verify_parity(report, "test")
        bad = copy.deepcopy(report)
        bad["cases"][0]["actual_ids"] = [1, 3]
        with self.assertRaisesRegex(ValueError, "native ID mismatch"):
            m.verify_parity(bad, "test")

    def test_blank_generation_does_not_count_as_an_answer(self):
        release = dict(source_sha="a" * 40, llama_sha="b" * 40, tokenizer_overlay_sha256="c" * 64,
                       apks={"app": {"sha256": "d" * 64}, "app_test": {"sha256": "e" * 64}})
        manifest = dict(run_id="test", build_sha=release["source_sha"], model_sha256=m.MODEL,
                        template_sha256=m.TEMPLATE, fixture_sha256=m.FIXTURE, case_set_sha256=m.CASE_SET,
                        llama_sha=release["llama_sha"], tokenizer_overlay_sha256=release["tokenizer_overlay_sha256"],
                        apk_sha256="d" * 64, test_apk_sha256="e" * 64, sampling=m.SAMPLING, seeds=[17],
                        threads=4, case_timeout_ms=180000, context={"requested": 4096, "allocated": 4096})
        cases = [{"case_id": str(i)} for i in range(4)]
        rows = [dict(case_id=str(i), seed=17, status="ok", used_sources_status="finalized_prompt",
                     generation_skipped=False,
                     generation=dict(isolated_count_consistency=True, prompt_tokens=10, generated_tokens=1, stop_reason="EOS"),
                     measurement=dict(prompt_tokens=10, model_sha256=m.MODEL)) for i in range(4)]
        m.verify_answers(manifest, rows, release, cases, "test")
        rows[0]["generation"]["generated_tokens"] = 0
        with self.assertRaisesRegex(ValueError, "unexpected stop/count"):
            m.verify_answers(manifest, rows, release, cases, "test")


if __name__ == "__main__":
    unittest.main(verbosity=2)
