"""Review-only execution of copied frozen tests; no CLI or device path."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
ROOT = Path(__file__).parent
ATTEMPTS = []


def denied(*args, **kwargs):
    ATTEMPTS.append("unexpected subprocess invocation")
    raise AssertionError("External subprocess execution is forbidden in this review")


def audit(event, args):
    if event in {"subprocess.Popen", "os.system", "os.posix_spawn", "os.spawn"}:
        denied()


sys.addaudithook(audit)
with patch.object(subprocess, "run", denied), patch.object(subprocess, "Popen", denied):
    spec = importlib.util.spec_from_file_location("frozen_v4_final_tests", ROOT / "test_physical_synthetic.py")
    tests = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tests)
    names = [
        "test_legacy_released_manifest_is_rejected_before_any_command",
        "test_parity_reuse_rejects_missing_or_changed_prior_released_app",
        "test_parity_reuse_rejects_missing_or_malformed_eog_classification_facts",
        "test_changed_test_source_keeps_production_identity_and_fresh_config",
        "test_test_only_policy_rejects_changed_production_native_and_unreviewed_scope",
        "test_host_identity_wrong_hash_or_model_binding_rejected",
        "test_explicit_cross_release_parity_reuse_preserves_native_identity_scope",
        "test_parity_reuse_rejects_changed_native_model_template_and_pins",
        "test_parity_reuse_rejects_stale_rejected_incomplete_or_missing_approval",
        "test_test_only_update_never_installs_when_current_app_mismatches",
        "test_progress_collection_failure_keeps_partial_and_separate_error",
        "test_progress_is_diagnostic_not_completion_and_rejects_truncation_or_wrong_run",
        "test_unreleased_candidate_stops_before_any_command",
        "test_parity_status_ok_cannot_hide_changed_actual_token_ids",
        "test_blank_generation_does_not_count_as_an_answer",
    ]
    suite = unittest.TestSuite(tests.SafetyTests(name) for name in names)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    m = tests.m
    native = Path("/Users/andrewherrera/skein-worktrees/conference-demo-20260929/build/agent-logs/fold/physical-5ae91c2-20260929T102342Z-v2/native/native-parity.json")
    assert m.digest(native) == "34e0dd8f53e6a659131b84fbe696aeaec9a8bcbe7208e09e3ab3bf876547f727"
    report = json.loads(native.read_text())
    m.verify_parity(report, report["run_id"])
    m.verify_native_eog(report)
    (ROOT / "independent-prior-token-guard.json").write_text(json.dumps(dict(
        native_report_sha256=m.digest(native), token_cases=len(report["cases"]),
        classification_guard="PASS", generated_stopping="unmeasured",
        raw_summary_or_process_dump_read=False, device_action=False), indent=2) + "\n")
    release = dict(test_only_update=True, test_build_sha="f" * 40,
                   source_sha=m.APP_SOURCE, llama_sha="b" * 40, tokenizer_overlay_sha256="c" * 64,
                   apks={"app": {"sha256": m.APP_APK}, "app_test": {"sha256": "e" * 64}})
    manifest = dict(run_id="review", build_sha=m.APP_SOURCE, model_sha256=m.MODEL,
                    template_sha256=m.TEMPLATE, fixture_sha256=m.FIXTURE, case_set_sha256=m.CASE_SET,
                    llama_sha=release["llama_sha"], tokenizer_overlay_sha256=release["tokenizer_overlay_sha256"],
                    apk_sha256=m.APP_APK, test_apk_sha256="e" * 64, sampling=m.SAMPLING, seeds=[17],
                    threads=4, case_timeout_ms=180000, context={"requested":4096,"allocated":4096},
                    test_build_sha=release["test_build_sha"],
                    test_build_sha_provenance="declared host opt-in test source; installed test APK digest measured",
                    model_blake3=m.MODEL_BLAKE3, model_blake3_provenance="host_declared_bound_to_device_sha256",
                    host_model_identity_evidence_sha256=m.HOST_IDENTITY)
    cases = [{"case_id": str(i)} for i in range(4)]
    rows = [dict(case_id=str(i), seed=17, status="ok", used_sources_status="finalized_prompt",
                 generation_skipped=False,
                 generation=dict(isolated_count_consistency=True,prompt_tokens=10,generated_tokens=1,stop_reason="EOS"),
                 measurement=dict(prompt_tokens=10,model_sha256=m.MODEL)) for i in range(4)]
    m.verify_answers(manifest, rows, release, cases, "review")
    probes = []
    for key in ("test_build_sha", "test_build_sha_provenance", "model_blake3",
                "model_blake3_provenance", "host_model_identity_evidence_sha256", "test_apk_sha256"):
        bad = copy.deepcopy(manifest)
        bad[key] = "wrong"
        try:
            m.verify_answers(bad, rows, release, cases, "review")
        except ValueError:
            probes.append({"mutation": key, "rejected": True})
        else:
            raise AssertionError("manifest mutation accepted: " + key)
    try:
        m.verify_answers(manifest, rows[:3], release, cases, "review")
    except ValueError:
        probes.append({"mutation": "partial_three_of_four_rows", "rejected": True})
    else:
        raise AssertionError("partial answer rows accepted")
    record = dict(classification="safe independent subset; not a replacement for owner full 31-case log",
                  tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                  skipped=len(result.skipped), selected_names=names, extra_manifest_probes=probes,
                  subprocess_attempts=ATTEMPTS, restricted_v2_fixtures_read=False,
                  main_called=False, execute_path_called=False)
    (ROOT / "safe-subset-result.json").write_text(json.dumps(record, indent=2) + "\n")
    if not result.wasSuccessful() or ATTEMPTS:
        raise SystemExit(1)
