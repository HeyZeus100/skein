from pathlib import Path
import collections,hashlib,json,subprocess,zipfile,xml.etree.ElementTree as E,re
w=Path('/Users/andrewherrera/skein-worktrees/file-reload-resume-20260930');p=w/'build/agent-logs/file-reload-20260930';out=Path(__file__).parent;h=lambda b:hashlib.sha256(b).hexdigest()
inv=json.loads((p/'durable-source-1.json').read_text());review=json.loads((p/'durable-full-1-review.json').read_text());baseline=json.loads((p/'baseline-comparison.json').read_text());negative=json.loads((p/'durable-negative-1-review.json').read_text())
def scan(z,allowed=None):
 cases={};counts=collections.Counter();files=[]
 for n in z.namelist():
  if not n.endswith('.xml') or (allowed is not None and n not in allowed):continue
  data=z.read(n);root=E.fromstring(data);cs=list(root.iter('testcase'));assert int(root.get('tests'))==len(cs);cc=collections.Counter()
  for c in cs:
   k=(n,c.get('classname'),c.get('name'));assert k not in cases
   result=next((x for x in ['failure','error','skipped'] if c.find(x) is not None),'pass');cc[result]+=1
   detail=E.tostring(c.find(result),encoding='unicode') if result!='pass' else None
   cases[k]=(result,detail)
  for attr,label in [('failures','failure'),('errors','error'),('skipped','skipped')]:assert int(root.get(attr,0))==cc[label]
  counts.update(cc);files.append({'path':n,'sha256':h(data),'counts':dict(cc)})
 return cases,dict(counts),files
with zipfile.ZipFile(p/'durable-full-1-xml.zip') as z:
 actual,counts,files=scan(z)
 for r in review['files']:assert h(z.read(r['path']))==r['sha256']
assert counts=={'pass':896,'skipped':18};assert len(files)==127;assert h((p/'durable-full-1-xml.zip').read_bytes())==review['archive_sha256']
bpath=w/baseline['baseline'];assert h(bpath.read_bytes())==baseline['baseline_sha256']
with zipfile.ZipFile(bpath) as z:old,oldcounts,oldfiles=scan(z,allowed={r['path'] for r in files})
assert len(old)==878 and len(actual)==914;assert set(old)<=set(actual);assert all(actual[k]==v for k,v in old.items());added=sorted(set(actual)-set(old));assert len(added)==36
with zipfile.ZipFile(p/'durable-negative-1-xml.zip') as z:
 neg,negcounts,negfiles=scan(z)
 for r in negative['files']:assert h(z.read(r['path']))==r['sha256']
assert negcounts=={'failure':2}
for k,v in neg.items():assert k[2]=='qualified AIOUT survivor reserves before any drain and reloads after commit without pruning' and 'expected not to be: null' in v[1]
path='app/src/main/kotlin/app/skein/shell/DocumentDeleteCoordinator.kt';base=subprocess.check_output(['git','show',inv['base']+':'+path],cwd=w,text=True)
with zipfile.ZipFile(p/'durable-source-1.zip') as positive,zipfile.ZipFile(p/'durable-negative-source.zip') as negsource:
 for r in inv['files']:
  data=positive.read(r['path']);assert h(data)==r['sha256'] and len(data)==r['bytes'];assert (w/r['path']).read_bytes()==data
  if r['path']!=path:assert negsource.read(r['path'])==data
 pos=positive.read(path).decode();negtext=negsource.read(path).decode()
 def method(s):return s[s.index('    fun request(id: DocId) {'):s.index('    fun cancel() {')]
 assert negtext==pos.replace(method(pos),method(base),1)
log=(p/'durable-full-1.log').read_text();assert 'BUILD SUCCESSFUL in 38s' in log
executed=[':app:testDevDebugUnitTest',':app:testFossDebugUnitTest',':feature:editor:testDebugUnitTest',':app:compileDevDebugAndroidTestKotlin',':app:compileFossDebugAndroidTestKotlin',':feature:editor:compileDebugAndroidTestKotlin']
for task in executed:assert re.search(r'^> Task '+re.escape(task)+r'$',log,re.M)
for task in [':app:ktlintCheck',':feature:editor:ktlintCheck']:assert '> Task '+task+' UP-TO-DATE' in log
required=['two dirty body panes refuse before forced persistence or deletion','two dirty title panes refuse before forced persistence or deletion','two dirty metadata panes refuse before forced persistence or deletion','pane enrolled after final readiness cannot admit edits before commit and lock','abandoned composition unregisters its constructor enrollment on scope completion','lock after commit preserves precommit dirty body title and metadata durably']
for name in required:assert any(k[2]==name and v[0]=='pass' for k,v in actual.items())
r={'reviewer':'/root/recovery','scope':'independent actual XML/hash, frozen source and exact-method negative control audit; no reviewer builds/device','verdict':'PASS within bounded host implementation scope','source_base':inv['base'],'source_files':inv['files'],'all8_live_hashes_restored_to_verified_positive_source':True,'positive_archive_sha256':h((p/'durable-full-1-xml.zip').read_bytes()),'positive_counts':counts,'xml_files':len(files),'all878_prior_case_outcomes_and_skip_details_preserved':True,'exact_new_case_count':36,'added':[{'xml':k[0],'class':k[1],'name':k[2]} for k in added],'negative':{'archive_sha256':h((p/'durable-negative-1-xml.zip').read_bytes()),'counts':negcounts,'exact_original_request_method_only_restored':True,'other7_files_and_remaining_coordinator_source_identical':True,'failure':'Both dev/foss expected missing qualified-AIOUT delete prompt; this is not a whole-old-commit execution.'},'executed_tasks':executed,'lint':'Both ktlintCheck tasks UP-TO-DATE in final full gate; same frozen sources; no fresh-lint-execution claim.','findings':{'F1':'Resolved source and passing divergent body/title/metadata refusal regressions.','F2':'Resolved constructor enrollment and passing final-validation-to-COMMIT gap+lock regression.','F3':'Resolved scope completion cleanup and passing abandoned-composition regression.'},'required_regressions_pass':required,'original_findings_preserved':['review-snapshot-01.json','review-snapshot-02.json'],'runtime_physical':'No new runtime execution or physical acceptance; compiled AndroidTest tasks are not executed instrumentation.','files':files}
f=out/'final-review.json';f.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'receipt':str(f),'sha256':h(f.read_bytes()),'counts':counts,'xml':len(files),'added':len(added),'negative':negcounts,'verdict':r['verdict']},indent=2))
