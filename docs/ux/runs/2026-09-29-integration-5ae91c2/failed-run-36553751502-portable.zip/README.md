# Foldable run 36553751502 — original failure

Source: `5ae91c238612bdd9b1511b3716d34b4fa5960dd2`. Explicit requested profile: `7.6in Foldable`.

The exact profile existed in the selected SDK 12.0 catalog. The SDK step then failed at `emulator -version`: `qemu-system-x86_64` could not load `libpulse.so.0` (exit 127). This is a Linux host prerequisite failure before AVD creation or test execution.

No runtime acceptance is claimed: zero testcase identities executed, both required cases missing, zero of five geometry records, no AVD configuration or app/test APKs. Original workflow, helper, test and reviewer sources are included.

The artifact ZIP, raw job-log ZIP, API snapshots and derived reviews are unchanged copies. `ORIGINAL-SHA256SUMS` preserves the original owning-tree inventory; `SHA256SUMS` covers this portable directory. Absolute paths inside original JSON are provenance, not portable lookup paths; the same basenames live beside this README.

The separate prerequisite patch and any later dispatch do not replace this failed evidence. Source identity is the host-declared checkout/API head, not installed-package attestation.
