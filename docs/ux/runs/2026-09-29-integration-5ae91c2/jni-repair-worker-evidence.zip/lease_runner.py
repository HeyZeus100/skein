import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

root = Path.cwd()
logs = root / 'build/agent-logs'
lease = Path('/Users/andrewherrera/skein-session-coordination/20260929/build.lock')
token = str(uuid.uuid4())
owner = dict(role='conference-jni-callback-20260929', worktree=str(root), pid=os.getpid(),
             token=token, start=datetime.datetime.now(datetime.timezone.utc).isoformat())
try:
    lease.mkdir()
except FileExistsError:
    print('BUILD_LEASE_BUSY', (lease / 'owner.json').read_text() if (lease / 'owner.json').exists() else 'owner metadata pending', flush=True)
    sys.exit(75)
(lease / 'owner.json').write_text(json.dumps(owner, indent=2) + '\n')
env = os.environ.copy()
env['JAVA_HOME'] = '/opt/homebrew/Cellar/openjdk@17/17.0.20.1/libexec/openjdk.jdk/Contents/Home'
env['ANDROID_HOME'] = '/Users/andrewherrera/android-sdk'
commands = {
    'baseline': ['./gradlew', '--max-workers=2', ':inference-service:testDevDebugUnitTest', '--tests', 'app.skein.inference.service.LlamaNativeSurfaceTest'],
    'fixed': ['./gradlew', '--max-workers=2', ':inference-service:testDevDebugUnitTest', '--tests', 'app.skein.inference.service.LlamaNativeSurfaceTest'],
    'checks': ['./gradlew', '--max-workers=2', ':inference-service:check', ':inference-service:ktlintCheck', ':inference-service:compileDevDebugAndroidTestKotlin', ':inference-service:compileFossDebugAndroidTestKotlin', ':app:compileDevDebugAndroidTestKotlin', ':app:compileFossDebugAndroidTestKotlin'],
}
print('BUILD_LEASE_ACQUIRED', json.dumps(owner), flush=True)
try:
    for request in sys.stdin:
        phase = request.strip()
        if phase == 'release':
            break
        if phase not in commands:
            print('UNKNOWN_PHASE', phase, flush=True)
            continue
        target = logs / phase
        target.mkdir(exist_ok=False)
        command = commands[phase]
        (target / 'command.json').write_text(json.dumps(command) + '\n')
        print('START', phase, flush=True)
        with (target / 'gradle.log').open('w') as output:
            result = subprocess.run(command, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT)
        (target / 'exit.txt').write_text(str(result.returncode) + '\n')
        results = root / 'inference-service/build/test-results'
        if results.exists():
            shutil.copytree(results, target / 'test-results')
        print('FINISH', phase, 'EXIT', result.returncode, flush=True)
finally:
    stored = json.loads((lease / 'owner.json').read_text())
    if stored.get('token') == token and stored.get('pid') == os.getpid():
        (lease / 'owner.json').unlink()
        lease.rmdir()
        print('BUILD_LEASE_RELEASED', flush=True)
