#!/usr/bin/env python3
"""Offline independent audit of frozen fresh40 raw JSON; never invokes retrieval.

No production evaluator module is imported. Bounded BLAKE3 compression is adapted
from the earlier independent host source reviewer, not the Kotlin implementation.
The fixed corpus is deliberately checked as 22 short, single-H1, single-chunk
documents; unsupported structure fails closed rather than guessing a chunk map.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import subprocess
import unicodedata

FIXTURE = "testing/src/main/resources/eval/rejection-validation-20260930.json"
FIXTURE_SHA = "653b79ce9ab1c36776b5876d1b5d687a1d335f811f388b832fd0d9d258952674"
CANDIDATE = "687c8eea8342779b3d87517fc1f2cd20cd4385fb"
EVALUATOR = "11e308155ba6e67bab873fec4325c8c9ec42a70c"
ROOTS = ("core/rag/src/main", "core/model/src/main",
         "core/vault/src/main/kotlin/app/skein/core/vault/index",
         "core/vault/src/main/kotlin/app/skein/core/vault/repository")
EVAL_FILES = (
    "testing/src/main/kotlin/app/skein/testing/eval/FreshContextualValidationFixture.kt",
    "testing/src/main/kotlin/app/skein/testing/eval/ExpandedRetrievalMetrics.kt",
    "testing/src/main/kotlin/app/skein/testing/eval/FreshContextualValidationReport.kt",
    "testing/src/test/kotlin/app/skein/testing/eval/FreshContextualValidationFixtureTest.kt",
    "testing/src/test/kotlin/app/skein/testing/eval/ExpandedRetrievalMetricsTest.kt",
    "testing/src/test/kotlin/app/skein/testing/eval/FreshContextualValidationReportTest.kt",
    "core/vault/src/retrievalEvaluation/kotlin/app/skein/core/vault/eval/FreshContextualValidationEvaluation.kt",
    "core/vault/src/retrievalEvaluation/kotlin/app/skein/core/vault/eval/RealRetrievalEvaluationTest.kt",
    "docs/eval/FRESH_CONTEXTUAL_VALIDATION_20260930.md", "tools/eval/run_real_retrieval.py",
    "tools/eval/test_run_real_retrieval.py", ".github/workflows/retrieval-diagnostic.yml", FIXTURE,
)
NO_EMBEDDER = "recall stage=vector skipped: no embedder loaded; degrading to lexical + graph"
RESULT_FIELDS = ("original_query", "recall_query", "resolution", "anchor_document_ids",
                 "evidence", "original_candidates", "evidence_members", "exclusion_counts")
IDENTITY_FIELDS = ("chunk_id", "doc_id", "doc_title", "text", "source_kind",
                   "revision_hash", "byte_start", "byte_end", "chunk_ord")
SIGNAL_FIELDS = ("score", "recalled_by", "recall_scores")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(body):
    return body.replace("\r\n", "\n").replace("\r", "\n")


def blake3_short(data):
    require(len(data) <= 1024, "BLAKE3 single-chunk bound exceeded")
    iv = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
          0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]
    permutation = [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8]
    cv = iv[:]
    blocks = [data[i:i + 64] for i in range(0, len(data), 64)] or [b""]
    for number, block in enumerate(blocks):
        flags = (1 if number == 0 else 0) | (10 if number == len(blocks) - 1 else 0)
        v = cv[:] + iv[:4] + [0, 0, len(block), flags]
        message = list(struct.unpack("<16I", block.ljust(64, b"\0")))

        def rotate(x, amount):
            return ((x >> amount) | (x << (32 - amount))) & 0xffffffff

        def mix(a, b, c, d, x, y):
            v[a] = (v[a] + v[b] + x) & 0xffffffff
            v[d] = rotate(v[d] ^ v[a], 16)
            v[c] = (v[c] + v[d]) & 0xffffffff
            v[b] = rotate(v[b] ^ v[c], 12)
            v[a] = (v[a] + v[b] + y) & 0xffffffff
            v[d] = rotate(v[d] ^ v[a], 8)
            v[c] = (v[c] + v[d]) & 0xffffffff
            v[b] = rotate(v[b] ^ v[c], 7)

        for _ in range(7):
            mix(0, 4, 8, 12, message[0], message[1])
            mix(1, 5, 9, 13, message[2], message[3])
            mix(2, 6, 10, 14, message[4], message[5])
            mix(3, 7, 11, 15, message[6], message[7])
            mix(0, 5, 10, 15, message[8], message[9])
            mix(1, 6, 11, 12, message[10], message[11])
            mix(2, 7, 8, 13, message[12], message[13])
            mix(3, 4, 9, 14, message[14], message[15])
            message = [message[i] for i in permutation]
        cv = [v[i] ^ v[i + 8] for i in range(8)]
    return struct.pack("<8I", *cv).hex()


def revision(body):
    # NewDocument defaults to empty frontmatter; repository adds only excluded id.
    return blake3_short(b"skein/revision/v1\0" + struct.pack("<Q", 2) + b"{}" + canonical(body).encode())


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def same(actual, expected, label):
    if type(expected) is float:
        require(finite(actual) and math.isclose(actual, expected, rel_tol=0, abs_tol=1e-12), label)
    else:
        require(type(actual) is type(expected) and actual == expected, label)


def unique_rows(rows, key, expected, label):
    require(isinstance(rows, list), label + " is not an array")
    require([row[key] for row in rows] == expected, label + " missing, reordered or duplicate")
    return {row[key]: row for row in rows}


def approximate_tokens(text):
    # Independent Unicode-category scan of the declared approximate tokenizer.
    require(all(ord(c) <= 0xffff for c in text), "unsupported surrogate-width token input")
    total, run = 0, 0
    for c in text + " ":
        if unicodedata.category(c)[0] in "LN":
            run += 1
        else:
            total += (run + 4) // 5
            run = 0
            if not c.isspace():
                total += 1
    return total


def expected_short_chunk(body):
    require("\r" not in body, "frozen corpus LF assumption changed")
    headings = re.findall(r"(?m)^#{1,6}(?:[ \t].*)?$", body)
    require(len(headings) == 1 and body.startswith("# "), "unsupported short-note heading structure")
    heading = body.split("\n", 1)[0][2:].strip().rstrip("#").strip()
    text = "# " + heading + "\n\n" + body
    tokens = approximate_tokens(text)
    require(tokens <= 512, "frozen short-note packing bound exceeded")
    return text, tokens


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], check=True, timeout=60,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout


def source_receipt(repo, build):
    require(re.fullmatch(r"[0-9a-f]{40}", build), "full build source ID required")
    records = []
    for freeze, roots in ((CANDIDATE, ROOTS), (EVALUATOR, EVAL_FILES)):
        git(repo, "merge-base", "--is-ancestor", freeze, build)
        frozen = git(repo, "ls-tree", "-r", "--name-only", freeze, "--", *roots).decode().splitlines()
        current = git(repo, "ls-tree", "-r", "--name-only", build, "--", *roots).decode().splitlines()
        require(frozen == current and frozen, "source inventory changed after freeze")
        if freeze == EVALUATOR:
            require(set(frozen) == set(EVAL_FILES), "evaluator inventory incomplete")
        for path in frozen:
            original = git(repo, "show", freeze + ":" + path)
            measured = git(repo, "show", build + ":" + path)
            require(original == measured, "frozen source changed: " + path)
            records.append({"path": path, "freeze": freeze, "sha256": sha(original)})
    return records


def bounds(item, body):
    start, end = item.get("byte_start"), item.get("byte_end")
    raw = body.encode()
    if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(raw):
        return False
    try:
        raw[:start].decode("utf-8")
        raw[:end].decode("utf-8")
    except UnicodeDecodeError:
        return False
    return True


def identity(item):
    return {field: item.get(field) for field in IDENTITY_FIELDS}


def signals(item):
    return {field: item.get(field) for field in SIGNAL_FIELDS}


def normalize_hit(item):
    value = dict(item)
    value["recalled_by"] = sorted(value.get("recalled_by", []))
    return value


def normalize_result(sample):
    value = {field: sample[field] for field in RESULT_FIELDS}
    value["anchor_document_ids"] = sorted(value["anchor_document_ids"])
    value["evidence"] = [normalize_hit(item) for item in value["evidence"]]
    value["original_candidates"] = [normalize_hit(item) for item in value["original_candidates"]]
    value["evidence_members"] = {key: [normalize_hit(item) for item in items]
                                  for key, items in value["evidence_members"].items()}
    return value


def signal_valid(item):
    recalls = item.get("recalled_by")
    scores = item.get("recall_scores")
    return (finite(item.get("score")) and isinstance(recalls, list)
            and len(recalls) == len(set(recalls)) and set(recalls) <= {"LEXICAL", "VECTOR", "GRAPH"}
            and isinstance(scores, dict) and set(scores) <= {"LEXICAL", "VECTOR", "GRAPH"}
            and all(finite(score) for score in scores.values()))


def validate_snapshot(section, fixture):
    snapshot = section["snapshot"]
    sources = {doc["id"]: doc for doc in fixture["documents"]}
    spaces = snapshot["space_mapping"]
    aliases = {doc["persona_id"] for doc in sources.values()} | {"default"}
    require(set(spaces) == aliases and len(set(spaces.values())) == len(spaces), "Space mapping aliases/collisions")
    require(all(isinstance(v, str) and v for v in spaces.values()), "invalid Space identity")
    docs = unique_rows(snapshot["documents"], "doc_id", list(sources), "snapshot documents")
    for key, doc in docs.items():
        source = sources[key]
        expected = dict(title=source["title"], kind="NOTE", persona_id=spaces[source["persona_id"]],
                        raw_body=source["body_md"], raw_body_sha256=sha(source["body_md"].encode()),
                        body_snapshot=canonical(source["body_md"]),
                        body_sha256=sha(canonical(source["body_md"]).encode()),
                        revision_hash=revision(source["body_md"]), content_hash=revision(source["body_md"]))
        for name, value in expected.items():
            same(doc.get(name), value, "immutable source mismatch " + key + ":" + name)
        require(doc["frontmatter_snapshot"] in ({}, {"id": key}), "unexpected synthetic frontmatter")
    indexed = snapshot["indexed_chunks"]
    require(len(indexed) == len(docs), "short-note whole-index count")
    require(len({row["chunk_id"] for row in indexed}) == len(indexed), "duplicate stored chunk ID")
    require({row["doc_id"] for row in indexed} == set(docs), "missing or orphan stored document")
    by_id = {}
    for row in indexed:
        doc = docs[row["doc_id"]]
        raw = doc["raw_body"]
        expected_text, count = expected_short_chunk(raw)
        expected = dict(ord=0, stored_text=expected_text, stored_revision_hash=doc["revision_hash"],
                        current_revision_hash=doc["revision_hash"], raw_byte_start=0, raw_byte_end=len(raw.encode()),
                        token_count=count, embedder_id="pending", embedder_version=0,
                        enumeration_scores_are_query_signals=False)
        for name, value in expected.items():
            same(row.get(name), value, "stored chunk mismatch " + str(row["chunk_id"]) + ":" + name)
        require(type(row["chunk_id"]) is int and row["chunk_id"] > 0, "invalid stored chunk ID")
        assembled = row["canonical_identity"]
        expected_identity = dict(chunk_id=row["chunk_id"], doc_id=doc["doc_id"], doc_title=doc["title"],
                                 source_kind="NOTE", text=expected_text, revision_hash=doc["revision_hash"],
                                 byte_start=0, byte_end=len(doc["body_snapshot"].encode()), chunk_ord=0)
        require(identity(assembled) == expected_identity and signal_valid(assembled), "unbound assembled stored identity")
        by_id[row["chunk_id"]] = assembled
    request_rows = unique_rows(snapshot["requests"], "id", [q["id"] for q in fixture["queries"]], "raw requests")
    for query in fixture["queries"]:
        request = request_rows[query["id"]]
        turns = query.get("conversation", {}).get("turns", [])
        users = [turn["content"] for turn in turns if turn["role"] == "user"]
        pins = [pin for turn in turns for pin in turn.get("source_pins", [])]
        expected_pins = []
        for pin in pins:
            doc = docs[pin["doc_id"]]
            require(pin["revision"] == "current" and pin["body_sha256"] == doc["body_sha256"], "frozen source-pin hash")
            require(spaces[pin["persona_id"]] == doc["persona_id"], "frozen source-pin scope")
            expected_pins.append(dict(doc_id=doc["doc_id"], revision_hash=doc["revision_hash"], persona_id=doc["persona_id"]))
        expected = dict(query=query["query"], persona_id=spaces[query["persona_id"]],
                        prior_user_query=users[-1] if users else None, source_pins=expected_pins,
                        oracle_or_assistant_text_supplied=False)
        for name, value in expected.items():
            same(request.get(name), value, "request differs from raw user/pin contract: " + name)
    historical = [doc for doc in sources.values() if doc.get("previous_revisions")]
    traces = snapshot["revision_replay"]
    unique_rows(traces, "doc_id", [doc["id"] for doc in historical], "revision replay")
    for source, trace in zip(historical, traces):
        doc = docs[source["id"]]
        require(trace["status"] == "EXECUTED_REPOSITORY_UPDATE_AND_INGEST", "revision trace status")
        same(trace["current_revision_hash"], doc["revision_hash"], "current revision trace hash")
        current_ids = [row["chunk_id"] for row in indexed if row["doc_id"] == source["id"]]
        same(trace["current_chunk_ids"], current_ids, "current chunk trace IDs")
        require(type(trace["current_revision_ord"]) is int, "current revision ordinal")
        require(len(trace["history"]) == len(source["previous_revisions"]), "previous revision trace count")
        ords = []
        for original, old in zip(source["previous_revisions"], trace["history"]):
            body = original["body_md"]
            same(old["body_snapshot"], canonical(body), "historical immutable body")
            same(old["body_sha256"], sha(body.encode()), "historical body SHA")
            same(old["revision_hash"], revision(body), "historical BLAKE3 revision")
            require(old["revision_hash"] != doc["revision_hash"], "history/current collapse")
            require(type(old["revision_ord"]) is int and old["revision_ord"] < trace["current_revision_ord"], "historical ordinal")
            require(len(old["chunk_ids"]) == 1 and type(old["chunk_ids"][0]) is int and old["chunk_ids"][0] > 0,
                    "historical short-note indexed chunk receipt")
            ords.append(old["revision_ord"])
        require(ords == sorted(set(ords)), "nonmonotonic history")
    same(section["revision_replay"]["documents"], traces, "duplicated revision receipt differs")
    return docs, by_id, spaces


def required_spans(query, docs):
    spans = []
    for gold in query["relevant"]:
        require(gold["grade"] == 3 and gold["evidence"], "invalid frozen required evidence")
        body = docs[gold["doc_id"]]["body_snapshot"]
        require(body.count(gold["evidence"]) == 1, "required evidence not unique in immutable body")
        start = len(body[:body.index(gold["evidence"])].encode())
        spans.append(dict(doc_id=gold["doc_id"], revision_hash=docs[gold["doc_id"]]["revision_hash"],
                          byte_start=start, byte_end=start + len(gold["evidence"].encode())))
    return spans


def score_raw(query, sample, docs, indexed, persona, expanded):
    """Derive rank validity and union coverage from bytes, never reported scores."""
    evidence = sample["evidence"]
    candidates = sample["original_candidates"]
    member_map = sample["evidence_members"]
    violations, invalid = set(), set()
    ids = [item["chunk_id"] for item in candidates]
    candidates_by_id = {item["chunk_id"]: item for item in candidates}

    def reject(rank, reason):
        invalid.add(rank)
        violations.add(str(rank) + ":" + reason)

    if sample["original_query"] != query["query"]:
        violations.add("request:ORIGINAL_QUERY_CHANGED")
    if len(evidence) > 8:
        violations.add("result:OVER_LIMIT")
    if len(candidates) > 8:
        violations.add("candidates:OVER_LIMIT")
    if len(ids) != len(set(ids)):
        violations.add("candidates:DUPLICATE")
    if expanded:
        for candidate in candidates:
            if (candidate["chunk_id"] not in indexed or identity(candidate) != identity(indexed[candidate["chunk_id"]])
                    or not signal_valid(candidate)):
                violations.add("candidate:" + str(candidate["chunk_id"]) + ":UNVERIFIED")
        if set(member_map) != {str(item["chunk_id"]) for item in evidence}:
            violations.add("members:KEY_SET")
    elif candidates or member_map:
        violations.add("baseline:UNEXPECTED_EXPANDED_METADATA")
    first, used = {}, {}
    for rank, unit in enumerate(evidence, 1):
        key = unit["chunk_id"]
        if key in first:
            reject(rank, "DUPLICATE")
        first.setdefault(key, rank)
        doc = docs.get(unit["doc_id"])
        if doc is None:
            reject(rank, "MISSING_SOURCE")
            continue
        if doc["kind"] != "NOTE" or unit["source_kind"] != doc["kind"]:
            reject(rank, "UNSUPPORTED_SOURCE")
        if doc["persona_id"] != persona or unit["doc_id"] in query["forbidden_doc_ids"]:
            reject(rank, "OUT_OF_SCOPE")
        if unit["revision_hash"] != doc["revision_hash"]:
            reject(rank, "STALE_REVISION")
        if unit["doc_title"] != doc["title"] or not signal_valid(unit):
            reject(rank, "IDENTITY_OR_SIGNAL")
        if not bounds(unit, doc["body_snapshot"]):
            reject(rank, "INVALID_ANCHOR")
            continue
        if not expanded:
            if key not in indexed or identity(unit) != identity(indexed[key]):
                reject(rank, "UNINDEXED")
            continue
        if unit["text"].encode() != doc["body_snapshot"].encode()[unit["byte_start"]:unit["byte_end"]]:
            reject(rank, "SOURCE_BYTES")
        members = member_map.get(str(key), [])
        if not members:
            reject(rank, "NO_MEMBERS")
        member_ids = [item["chunk_id"] for item in members]
        if len(member_ids) != len(set(member_ids)):
            reject(rank, "DUPLICATE_MEMBER")
        order = [ids.index(i) if i in ids else -1 for i in member_ids]
        if -1 in order or order != sorted(order):
            reject(rank, "MEMBER_ORDER")
        representative = members[order.index(min(order))] if members else None
        if representative is None or representative["chunk_id"] != key or signals(representative) != signals(unit):
            reject(rank, "REPRESENTATIVE")
        for member in members:
            member_id = member["chunk_id"]
            if member_id in used and used[member_id] != rank:
                reject(used[member_id], "REUSED_MEMBER")
                reject(rank, "REUSED_MEMBER")
            used.setdefault(member_id, rank)
            if (member_id not in indexed or identity(member) != identity(indexed[member_id])
                    or member != candidates_by_id.get(member_id)):
                reject(rank, "UNVERIFIED_MEMBER")
            if (member["doc_id"] != unit["doc_id"] or member["revision_hash"] != unit["revision_hash"]
                    or type(member.get("byte_start")) is not int or type(member.get("byte_end")) is not int
                    or member["byte_start"] < unit["byte_start"] or member["byte_end"] > unit["byte_end"]):
                reject(rank, "MEMBER_OUTSIDE_UNIT")
    if expanded:
        for i, a in enumerate(evidence):
            for j, b in enumerate(evidence[:i]):
                if (a["doc_id"] == b["doc_id"] and a["revision_hash"] == b["revision_hash"]
                        and all(type(item.get(key)) is int for item in (a, b) for key in ("byte_start", "byte_end"))
                        and a["byte_start"] < b["byte_end"] and b["byte_start"] < a["byte_end"]):
                    reject(j + 1, "OVERLAP")
                    reject(i + 1, "OVERLAP")
    ranks = [i for i in range(1, min(len(evidence), 8) + 1) if i not in invalid]
    spans = required_spans(query, docs)
    covered = []
    for number, span in enumerate(spans):
        intervals = sorted((evidence[i - 1]["byte_start"], evidence[i - 1]["byte_end"]) for i in ranks
                           if evidence[i - 1]["doc_id"] == span["doc_id"]
                           and evidence[i - 1]["revision_hash"] == span["revision_hash"])
        through = span["byte_start"]
        for start, end in intervals:
            if end <= through:
                continue
            if start > through:
                break
            through = end
        if through >= span["byte_end"]:
            covered.append(number)
    return dict(covered_spans=len(covered), covered_span_ordinals=covered, total_spans=len(spans),
                raw_evidence_count=len(evidence), valid_ranks=ranks, provenance_violations=sorted(violations))


def inspect_sample(sample):
    require(finite(sample["elapsed_ms"]) and sample["elapsed_ms"] >= 0, "invalid sample timing")
    require(sample["status"] in {"EXECUTED", "ERROR", "TIMEOUT"}, "invalid attempted sample status")
    warnings = sample["stage_warnings"]
    require(isinstance(warnings, list) and all(isinstance(w, str) for w in warnings), "warning evidence")
    unexpected = [w for w in warnings if w != NO_EMBEDDER]
    available = sample["result_available"]
    require(type(available) is bool, "result_available boolean")
    if sample["status"] == "EXECUTED":
        require(available and not unexpected and sample["failure_type"] is None, "failed sample labelled executed")
    elif sample["status"] == "ERROR":
        require(sample["failure_type"] is not None or unexpected, "unexplained error")
    else:
        require(not available or any(" timed out " in w for w in unexpected), "unexplained timeout")
    for field in ("evidence", "original_candidates", "anchor_document_ids"):
        require(isinstance(sample[field], list), "raw sample array missing: " + field)
    require(isinstance(sample["evidence_members"], dict) and isinstance(sample["exclusion_counts"], dict), "raw metadata maps")
    require(all(type(n) is int and n >= 0 for n in sample["exclusion_counts"].values()), "exclusion count shape")
    if not available:
        require(all(sample[k] is None for k in ("original_query", "recall_query", "resolution")), "absent result carries query")
        require(not any(sample[k] for k in ("evidence", "original_candidates", "evidence_members", "anchor_document_ids", "exclusion_counts")),
                "absent result carries fabricated arrays")
    else:
        require(all(isinstance(sample[k], str) for k in ("original_query", "recall_query", "resolution")), "available result identity")


def audit_execution(row, query, docs, indexed, persona, expanded):
    status = row["status"]
    require(status in {"EXECUTED", "ERROR", "TIMEOUT", "UNEXECUTED"}, "row execution status")
    if status == "UNEXECUTED":
        for key, value in dict(attempted=False, warmup=None, samples=[], score=None, deterministic=False, strict_success=False).items():
            same(row.get(key), value, "unexecuted row fabricated " + key)
        return dict(status=status, attempted=False, deterministic=False, strict_success=False, score=None, samples=[])
    same(row["attempted"], True, "attempted execution lacks attempt")
    require(isinstance(row["warmup"], dict) and len(row["samples"]) == 3, "missing warmup/repetitions")
    for sample in [row["warmup"], *row["samples"]]:
        inspect_sample(sample)
    failures = [sample for sample in [row["warmup"], *row["samples"]] if sample["status"] != "EXECUTED"]
    if failures:
        same(status, failures[0]["status"], "row hides original first failed sample")
        for key, value in dict(score=None, deterministic=False, strict_success=False).items():
            same(row.get(key), value, "failed execution received " + key)
        return dict(status=status, attempted=True, deterministic=False, strict_success=False, score=None, samples=[])
    same(status, "EXECUTED", "successful raw samples mislabelled")
    samples = [score_raw(query, sample, docs, indexed, persona, expanded) for sample in row["samples"]]
    # Warmup is audited for source issues but never contributes measured credit.
    warmup = score_raw(query, row["warmup"], docs, indexed, persona, expanded)
    deterministic = all(normalize_result(s) == normalize_result(row["samples"][0]) for s in row["samples"])
    violations = sorted({v for sample in samples for v in sample["provenance_violations"]})
    total = len(query["relevant"])
    covered = min(sample["covered_spans"] for sample in samples)
    raw_count = max(sample["raw_evidence_count"] for sample in samples)
    score = dict(covered_spans=covered, total_spans=total, all_spans_covered=total > 0 and covered == total,
                 raw_evidence_count=raw_count,
                 valid_ranks=[i for i in samples[0]["valid_ranks"] if all(i in s["valid_ranks"] for s in samples)],
                 correct_absence_rejection=total == 0 and raw_count == 0 and not violations,
                 false_absence_admission=total == 0 and raw_count > 0, provenance_violations=violations)
    reported = row["score"]
    require(isinstance(reported, dict), "successful execution score missing")
    for key, value in score.items():
        if key == "provenance_violations":
            require(isinstance(reported.get(key), list) and len(reported[key]) == len(set(reported[key]))
                    and sorted(reported[key]) == value, "provenance claims differ from independently checked bytes")
        else:
            same(reported.get(key), value, "score differs from independent raw audit: " + key)
    strict = deterministic and not violations and (score["all_spans_covered"] or score["correct_absence_rejection"])
    same(row["deterministic"], deterministic, "claimed determinism differs from actual raw samples")
    same(row["strict_success"], strict, "strict success differs from source/member/span audit")
    return dict(status=status, attempted=True, deterministic=deterministic, strict_success=strict,
                score=score, samples=samples, warmup_provenance_violations=warmup["provenance_violations"])


def independent_summary(rows, queries):
    answers = [row for row, query in zip(rows, queries) if query["relevant"]]
    absent = [row for row, query in zip(rows, queries) if not query["relevant"]]
    scores = [row["score"] for row in rows if row["score"] is not None]
    covered = sum(s["covered_spans"] for s in scores)
    violations = sum(len(s["provenance_violations"]) for s in scores)
    nondeterministic = sum(row["status"] == "EXECUTED" and not row["deterministic"] for row in rows)
    rejected = sum(bool(row["score"] and row["score"]["correct_absence_rejection"]) for row in absent)
    strict = sum(row["strict_success"] for row in rows)
    summary = dict(queries=40, answerable_queries=22, absence_queries=18, labelled_evidence_spans=24,
                   attempted=sum(row["attempted"] for row in rows), completed=sum(row["status"] == "EXECUTED" for row in rows),
                   scored=len(scores), covered_evidence_spans=covered, micro_span_coverage=covered / 24,
                   macro_span_coverage=sum((row["score"]["covered_spans"] if row["score"] else 0) / len(q["relevant"])
                                           for row, q in zip(rows, queries) if q["relevant"]) / 22,
                   any_span_successes=sum(s["covered_spans"] > 0 for s in scores),
                   all_span_successes=sum(row["strict_success"] for row in answers),
                   complete_conflict_queries=sum(row["strict_success"] for row, q in zip(rows, queries)
                                                 if q["category"] == "contradiction_unresolved"),
                   conflict_queries=sum(q["category"] == "contradiction_unresolved" for q in queries),
                   correct_absence_rejections=rejected,
                   false_absence_admissions=sum(bool(row["score"] and row["score"]["false_absence_admission"]) for row in absent),
                   absence_rejection_rate=rejected / 18,
                   empty_answer_rejections=sum(bool(row["score"] and row["score"]["raw_evidence_count"] == 0) for row in answers),
                   related_but_insufficient_admissions=sum(bool(row["score"] and row["score"]["raw_evidence_count"] > 0
                                                              and not row["score"]["all_spans_covered"]) for row in answers),
                   strict_successes=strict, strict_success_rate=strict / 40, provenance_violations=violations,
                   execution_errors=sum(row["status"] == "ERROR" for row in rows),
                   timeouts=sum(row["status"] == "TIMEOUT" for row in rows),
                   unexecuted=sum(row["status"] == "UNEXECUTED" for row in rows), nondeterministic_queries=nondeterministic,
                   hard_provenance_gate="FAIL" if violations or nondeterministic else "PASS" if len(scores) == 40 else "INCOMPLETE",
                   expanded_ranking_gate="INELIGIBLE")
    return summary


def audit(section, fixture, build):
    metadata = dict(schema_version=1, fixture_protocol_version=2, status="MEASURED_DIAGNOSTIC", fixture_sha256=FIXTURE_SHA,
                    candidate_freeze=CANDIDATE, evaluator_freeze=EVALUATOR, build_revision=build,
                    repetitions=3, warmups_per_query_mode=1, expanded_ranking_gate="INELIGIBLE", full_hybrid_gate="INELIGIBLE")
    for key, value in metadata.items():
        same(section.get(key), value, "attribution/protocol mismatch: " + key)
    queries = fixture["queries"]
    require(len(queries) == 40 and len(fixture["documents"]) == 22, "frozen denominator inventory")
    require(sum(bool(q["relevant"]) for q in queries) == 22 and sum(len(q["relevant"]) for q in queries) == 24,
            "frozen answer/span denominator")
    contexts = [q["id"] for q in queries if "conversation_context" in q["execution_requirements"]]
    revisions = [q["id"] for q in queries if "revision_replay" in q["execution_requirements"]]
    require(len(contexts) == 6 and len(revisions) == 4, "frozen runtime-boundary inventory")
    for key, value in dict(status="UNEXECUTED", executed=0, total=6, required_query_ids=contexts).items():
        same(section["application_context"].get(key), value, "app context credited or incomplete: " + key)
    same(section["revision_replay"]["status"], "EXECUTED_REPOSITORY_UPDATE_AND_INGEST", "revision component status")
    same(section["revision_replay"]["required_query_ids"], revisions, "revision required inventory")
    same(section["ingest_warnings"], [], "degraded setup")
    configuration = dict(chunker="Chunker(target=512,overlap=64)", tokenizer="ApproximateTokenizer", embedder=None,
                         vector_count=0, evidence_policy="production LexicalEvidenceGate defaults unchanged",
                         recall_timeout_ms=2000, call_timeout_ms=10000)
    for key, value in configuration.items():
        same(section["configuration"].get(key), value, "runtime configuration mismatch: " + key)
    docs, indexed, spaces = validate_snapshot(section, fixture)
    require(set(section["modes"]) == {"raw_string_baseline", "contextual_candidate"}, "mode inventory")
    modes = {}
    for name, mode in section["modes"].items():
        expanded = name == "contextual_candidate"
        same(mode["representation"], "EXPANDED_UNITS" if expanded else "INDEXED_CHUNKS", "representation attribution")
        raw_rows = unique_rows(mode["queries"], "id", [q["id"] for q in queries], "primary40 rows")
        reviewed, diagnostics = [], {}
        for query in queries:
            row = raw_rows[query["id"]]
            expected = dict(category=query["category"], answerable=bool(query["relevant"]), required_spans=len(query["relevant"]),
                            raw_query=query["query"], space_alias=query["persona_id"],
                            execution_requirements=sorted(query["execution_requirements"]),
                            required_span_anchors=required_spans(query, docs),
                            application_context_status="UNEXECUTED" if query["id"] in contexts else "NOT_APPLICABLE")
            for key, value in expected.items():
                same(row.get(key), value, "primary query/label/source anchor mismatch: " + query["id"] + ":" + key)
            if query["id"] in contexts:
                same(row["status"], "UNEXECUTED", "component API credited as app context")
            else:
                require("component_diagnostic" not in row, "unexpected separate diagnostic on supported row")
            reviewed.append(audit_execution(row, query, docs, indexed, spaces[query["persona_id"]], expanded))
            if "component_diagnostic" in row:
                diagnostics[query["id"]] = audit_execution(row["component_diagnostic"], query, docs, indexed,
                                                          spaces[query["persona_id"]], expanded)
        summary = independent_summary(reviewed, queries)
        for key, value in summary.items():
            same(mode["summary"].get(key), value, "summary differs from independent recomputation: " + name + ":" + key)
        modes[name] = dict(summary=summary, rows=[dict(id=q["id"], **r) for q, r in zip(queries, reviewed)],
                           component_diagnostics_excluded_from_primary=diagnostics)
    return dict(audit_status="PASS_RAW_REPORT_CONSISTENCY", application_context="UNEXECUTED",
                expanded_ranking_gate="INELIGIBLE", full_hybrid_gate="INELIGIBLE", modes=modes,
                snapshot_counts=dict(documents=len(docs), stored_chunks=len(indexed), requests=40, historical_documents=2))


def no_duplicate_keys(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, "duplicate JSON key: " + key)
        value[key] = item
    return value


def read_json(data):
    def nonfinite(value):
        raise ValueError("nonfinite JSON constant: " + value)
    return json.loads(data, object_pairs_hook=no_duplicate_keys, parse_constant=nonfinite)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True, help="local repository containing exact freeze/build commits")
    parser.add_argument("--report", type=Path, required=True, help="preserved actual retrieval.json")
    parser.add_argument("--expected-report-sha256", required=True, help="coordinator-sealed raw report digest")
    parser.add_argument("--build-revision", required=True)
    parser.add_argument("--output", type=Path, required=True, help="new receipt path within this ignored auditor directory")
    args = parser.parse_args()
    destination = args.output.resolve()
    require(destination.is_relative_to(Path(__file__).resolve().parent) and not destination.exists(), "output must be new and inside auditor directory")
    raw = args.report.read_bytes()
    require(re.fullmatch(r"[0-9a-f]{64}", args.expected_report_sha256)
            and sha(raw) == args.expected_report_sha256, "raw artifact hash mismatch")
    fixture_bytes = git(args.repo, "show", EVALUATOR + ":" + FIXTURE)
    require(sha(fixture_bytes) == FIXTURE_SHA, "frozen fixture bytes changed")
    sources = source_receipt(args.repo, args.build_revision)
    payload = read_json(raw)
    require(payload.get("build_revision") == args.build_revision, "outer report build attribution")
    result = audit(payload["fresh_contextual_validation"], read_json(fixture_bytes), args.build_revision)
    result.update(raw_report_sha256=sha(raw), fixture_sha256=FIXTURE_SHA, auditor_sha256=sha(Path(__file__).read_bytes()),
                  candidate_freeze=CANDIDATE, evaluator_freeze=EVALUATOR, build_revision=args.build_revision,
                  source_files=sources, limitations=[
                      "PASS means raw-report accounting and source attribution are internally consistent, not that retrieval quality passed.",
                      "JSON snapshot and revision traces are host/instrumentation declarations; independent APK, archive/API digest and actual JUnit checks remain required.",
                      "No attestation of runtime process memory, encrypted database bytes, actual SQL history retention, or physical Fold follows from JSON alone.",
                      "Six app conversation-context cases remain primary UNEXECUTED; component diagnostics cannot establish SendPipeline acceptance.",
                      "Independent scorer has no quality threshold, embedding qualification, human grading or answer-generation acceptance.",
                  ])
    destination.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(dict(path=str(destination), sha256=sha(destination.read_bytes()), status=result["audit_status"])))


if __name__ == "__main__":
    main()
