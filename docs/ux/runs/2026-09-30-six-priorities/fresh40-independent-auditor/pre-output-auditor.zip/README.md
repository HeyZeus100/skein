# Independent raw fresh40 report audit

This ignored reviewer tool is prepared before fresh40 outputs exist. It reads
preserved JSON and local frozen Git objects only. It never builds, calls a
retriever, contacts a device, dispatches CI, or changes source/gold/thresholds.
No test or actual artifact invocation has run yet. Root controls the test slot
and subsequent actual-artifact review.

The auditor independently checks the frozen candidate/evaluator source inventory
and ancestry; frozen fixture bytes; all 22 exact source documents; bounded BLAKE3
revision hashes; all short-note chunk bytes/breadcrumbs/token counts; Space and
current-revision identity; recorded historical revisions; raw user/source-pin
request mapping; exact UTF-8 ranges; original ranked positions; expanded members
and original signals; interval-union coverage of every required span; both
conflict spans; original nonempty absence admissions; failures and repetitions;
and all primary 40/22/18/24 summary fields. Six application-context rows must stay
empty `UNEXECUTED`; separate component diagnostics never affect primary credit.
Production evaluator code is not imported.

The 22 frozen notes are each short enough for one chunk, with one leading H1.
That bounded structure is checked explicitly; this is not a general Markdown
chunker. Revision BLAKE3 inputs are bounded to 1024 bytes and synthetic frontmatter
must be empty except for the repository's excluded document ID. The caller must
provide the coordinator-sealed report SHA and full build SHA. All inputs are
read-only. Output must be a new file inside this ignored audit directory.

After a serialized test grant, the exact synthetic-only command is:

```sh
python3 -m unittest -v test_audit_fresh40.py
```

After root supplies an actual artifact and source ID:

```sh
python3 audit_fresh40.py --repo /path/to/integration --report /path/to/preserved/retrieval.json --expected-report-sha256 FULL_SHA256 --build-revision FULL_GIT_SHA --output /absolute/path/inside/this/directory/actual-review.json
```

`PASS_RAW_REPORT_CONSISTENCY` means the recorded artifact agrees with independently
recomputed accounting. It is not a retrieval-quality pass. Candidate misses,
false admissions, provenance failures, timeouts, and unsupported primary rows are
preserved. No numerical acceptance threshold is introduced. Actual JUnit, artifact
API/archive digests, manifest/source records and built/installed APK attribution
still require their separate review. JSON cannot independently attest a running
process, database bytes, app context wiring, physical Fold behavior, embeddings,
answer generation or human grading.
