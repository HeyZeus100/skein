"""Synthetic auditor controls only. Does not call production retrieval or use fresh40 outputs."""
import copy
import unittest

import audit_fresh40 as audit


class AuditorControls(unittest.TestCase):
    def setUp(self):
        body = "Amber holds nine cups. Blue holds six jars."
        self.doc = dict(doc_id="synthetic-a", title="Crates", kind="NOTE", persona_id="space-a",
                        body_snapshot=body, raw_body=body, revision_hash=audit.revision(body))
        self.docs = {"synthetic-a": self.doc}
        self.query = dict(id="synthetic-query", query="What does amber hold?", category="synthetic",
                          persona_id="space-a", forbidden_doc_ids=[],
                          relevant=[dict(doc_id="synthetic-a", grade=3, evidence="Amber holds nine cups.")])
        self.first = self.hit(1, 0, len("Amber holds nine cups."))
        self.second = self.hit(2, len("Amber holds nine cups. "), len(body))
        self.indexed = {1: self.first, 2: self.second}

    def hit(self, key, start, end):
        doc = self.doc
        return dict(chunk_id=key, doc_id=doc["doc_id"], doc_title=doc["title"], source_kind="NOTE",
                    text=doc["body_snapshot"].encode()[start:end].decode(), revision_hash=doc["revision_hash"],
                    byte_start=start, byte_end=end, chunk_ord=key - 1, score=1.0,
                    recalled_by=["LEXICAL"], recall_scores={"LEXICAL": 2.0})

    def sample(self, evidence=None, candidates=None, members=None):
        return dict(status="EXECUTED", elapsed_ms=1.0, result_available=True, failure_type=None, stage_warnings=[],
                    original_query=self.query["query"], recall_query=self.query["query"], resolution="DIRECT",
                    anchor_document_ids=[], evidence=[self.first] if evidence is None else evidence,
                    original_candidates=[self.first] if candidates is None else candidates,
                    evidence_members={"1": [self.first]} if members is None else members, exclusion_counts={})

    def measured(self, sample, query=None, expanded=True):
        return audit.score_raw(query or self.query, sample, self.docs, self.indexed, "space-a", expanded)

    def test_public_blake3_vectors_and_bounded_refusal(self):
        self.assertEqual("af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262", audit.blake3_short(b""))
        self.assertEqual("6437b3ac38465133ffb63b75273a8db548c558465d79db03fd359c6cd5bd9d85", audit.blake3_short(b"abc"))
        with self.assertRaises(ValueError):
            audit.blake3_short(b"a" * 1025)

    def test_legitimate_raw_member_and_full_span(self):
        result = self.measured(self.sample())
        self.assertEqual(1, result["covered_spans"])
        self.assertEqual([], result["provenance_violations"])

    def test_exact_source_byte_forgery_cannot_get_credit(self):
        bad = dict(self.first, text="Invented cups.")
        result = self.measured(self.sample(evidence=[bad]))
        self.assertEqual(0, result["covered_spans"])
        self.assertIn("1:SOURCE_BYTES", result["provenance_violations"])

    def test_indexed_baseline_does_not_accept_forged_embedding_breadcrumb(self):
        bad = dict(self.first, text="# Invented\n\n" + self.first["text"])
        result = self.measured(self.sample(evidence=[bad], candidates=[], members={}), expanded=False)
        self.assertEqual(0, result["covered_spans"])
        self.assertIn("1:UNINDEXED", result["provenance_violations"])

    def test_expanded_member_changed_text_or_signal_is_rejected(self):
        for bad in (dict(self.first, text="Forged"), dict(self.first, score=9.0)):
            result = self.measured(self.sample(members={"1": [bad]}))
            self.assertEqual(0, result["covered_spans"])
            self.assertIn("1:UNVERIFIED_MEMBER", result["provenance_violations"])

    def test_stale_revision_and_wrong_space_and_forbidden_doc_are_rejected(self):
        bad = dict(self.first, revision_hash="0" * 64)
        self.assertIn("1:STALE_REVISION", self.measured(self.sample(evidence=[bad]))["provenance_violations"])
        self.docs["synthetic-a"] = dict(self.doc, persona_id="space-b")
        self.assertIn("1:OUT_OF_SCOPE", self.measured(self.sample())["provenance_violations"])
        self.docs["synthetic-a"] = self.doc
        query = dict(self.query, forbidden_doc_ids=["synthetic-a"])
        self.assertIn("1:OUT_OF_SCOPE", self.measured(self.sample(), query=query)["provenance_violations"])

    def test_conflict_requires_both_spans(self):
        query = dict(self.query, relevant=self.query["relevant"] + [dict(doc_id="synthetic-a", grade=3, evidence="Blue holds six jars.")])
        result = self.measured(self.sample(), query=query)
        self.assertEqual((1, 2), (result["covered_spans"], result["total_spans"]))
        expanded = dict(self.first, text=self.doc["body_snapshot"], byte_end=len(self.doc["body_snapshot"]))
        result = self.measured(self.sample(evidence=[expanded]), query=query)
        self.assertEqual((2, 2), (result["covered_spans"], result["total_spans"]))

    def test_partial_source_span_never_counts_as_whole(self):
        partial = self.hit(3, 0, 5)
        self.indexed[3] = partial
        result = self.measured(self.sample(evidence=[partial], candidates=[partial], members={"3": [partial]}))
        self.assertEqual([], result["provenance_violations"])
        self.assertEqual(0, result["covered_spans"])

    def test_adjacent_valid_ranges_union_and_one_byte_gap_does_not(self):
        left, right = self.hit(3, 0, 5), self.hit(4, 5, len(self.first["text"]))
        self.indexed.update({3: left, 4: right})
        full = self.sample(evidence=[left, right], candidates=[left, right], members={"3": [left], "4": [right]})
        self.assertEqual(1, self.measured(full)["covered_spans"])
        gap = self.hit(4, 6, len(self.first["text"]))
        self.indexed[4] = gap
        split = self.sample(evidence=[left, gap], candidates=[left, gap], members={"3": [left], "4": [gap]})
        self.assertEqual(0, self.measured(split)["covered_spans"])

    def test_utf8_mid_character_offset_is_invalid(self):
        self.assertFalse(audit.bounds(dict(byte_start=1, byte_end=3), "éx"))
        self.assertTrue(audit.bounds(dict(byte_start=0, byte_end=2), "éx"))

    def test_invalid_eighth_rank_is_not_backfilled_by_ninth(self):
        unrelated = [dict(self.second, chunk_id=i) for i in range(10, 17)]
        for item in unrelated:
            self.indexed[item["chunk_id"]] = item
        invalid = dict(self.second, chunk_id=999, text="Unknown")
        result = self.measured(self.sample(evidence=unrelated + [invalid, self.first], candidates=[], members={}), expanded=False)
        self.assertEqual(0, result["covered_spans"])
        self.assertNotIn(9, result["valid_ranks"])

    def test_duplicate_result_preserves_first_rank_and_consumes_second(self):
        result = self.measured(self.sample(evidence=[self.first, self.first], candidates=[], members={}), expanded=False)
        self.assertEqual([1], result["valid_ranks"])
        self.assertEqual(1, result["covered_spans"])
        self.assertIn("2:DUPLICATE", result["provenance_violations"])

    def test_reused_member_and_overlap_invalidate_both(self):
        other = dict(self.first, chunk_id=2)
        result = self.measured(self.sample(evidence=[self.first, other], candidates=[self.first],
                                           members={"1": [self.first], "2": [self.first]}))
        self.assertEqual(0, result["covered_spans"])
        for violation in ("1:REUSED_MEMBER", "2:REUSED_MEMBER", "1:OVERLAP", "2:OVERLAP"):
            self.assertIn(violation, result["provenance_violations"])

    def test_empty_stage_error_cannot_be_labelled_executed(self):
        sample = self.sample(evidence=[], candidates=[], members={})
        sample["stage_warnings"] = ["recall stage=lexical failed: ExampleFailure"]
        with self.assertRaises(ValueError):
            audit.inspect_sample(sample)

    def test_unexecuted_context_cannot_carry_score_or_samples(self):
        row = dict(status="UNEXECUTED", attempted=False, warmup=None, samples=[], score=None,
                   deterministic=False, strict_success=False)
        result = audit.audit_execution(row, self.query, self.docs, self.indexed, "space-a", True)
        self.assertIsNone(result["score"])
        for field, value in (("score", {}), ("samples", [self.sample()]), ("strict_success", True)):
            bad = dict(row, **{field: value})
            with self.assertRaises(ValueError):
                audit.audit_execution(bad, self.query, self.docs, self.indexed, "space-a", True)

    def test_fabricated_covered_count_is_rejected(self):
        sample = self.sample()
        row = dict(status="EXECUTED", attempted=True, warmup=sample, samples=[sample] * 3,
                   score=dict(covered_spans=0), deterministic=True, strict_success=True)
        with self.assertRaises(ValueError):
            audit.audit_execution(row, self.query, self.docs, self.indexed, "space-a", True)

    def test_raw_admission_is_preserved_even_when_provenance_invalid(self):
        query = dict(self.query, relevant=[])
        forged = dict(self.first, text="Invented")
        result = self.measured(self.sample(evidence=[forged]), query=query)
        self.assertEqual((0, 1), (result["total_spans"], result["raw_evidence_count"]))
        self.assertTrue(result["provenance_violations"])

    def test_determinism_compares_raw_results_without_latency(self):
        a, b = self.sample(), copy.deepcopy(self.sample())
        b["elapsed_ms"] = 500.0
        self.assertEqual(audit.normalize_result(a), audit.normalize_result(b))
        b["recall_query"] = "Different actual recalled query"
        self.assertNotEqual(audit.normalize_result(a), audit.normalize_result(b))

    def test_json_duplicate_keys_and_nonfinite_values_are_refused(self):
        for raw in ('{"score": 1, "score": 2}', '{"score": NaN}', '{"score": Infinity}'):
            with self.assertRaises(ValueError):
                audit.read_json(raw)

    def test_short_note_breadcrumb_and_token_count_are_independent(self):
        text, count = audit.expected_short_chunk("# Crates\n\nNine cups.\n")
        self.assertEqual("# Crates\n\n# Crates\n\nNine cups.\n", text)
        self.assertEqual(9, count)
        with self.assertRaises(ValueError):
            audit.expected_short_chunk("# Crates\n\n## Nested\n\nNine cups.")


if __name__ == "__main__":
    unittest.main(verbosity=2)
