# Failed foldable attempt 36559029738

Source: `2e1dcbafd645d4bb9348340905949bc5cae90acf`; explicit generic `7.6in Foldable`, API35.

Actual XML: 2 expected cases, 0 pass, 2 failures, 0 errors/skips; no duplicate/missing cases. Both reached framework CLOSED state but the window stayed 674x841dp. They failed before MainActivity launch; 0 geometry observations. Logcat records CLOSED/OPENED cleanup transitions for each test. No final standalone rotation attestation exists.

This capsule preserves all non-APK raw reports, catalog/config, logs, source snapshots and API metadata byte-for-byte. COPY_PROVENANCE.json maps each copied file. SHA256SUMS is the original evidence inventory; CAPSULE-SHA256SUMS covers this portable capsule. Raw APKs and the 156,519,596-byte full artifact ZIP remain at the original immutable paths in BINARY_ARTIFACT_REFERENCES.json, which includes verified byte sizes/digests and the remote artifact link. Those binary bytes are deliberately omitted here.

See failure-diagnosis.json for the bounded host-console transport proposal. No source change, build, device action, CI dispatch or Beads operation was performed during this review. Repository/runner identity metadata may be present in raw API/log records.
