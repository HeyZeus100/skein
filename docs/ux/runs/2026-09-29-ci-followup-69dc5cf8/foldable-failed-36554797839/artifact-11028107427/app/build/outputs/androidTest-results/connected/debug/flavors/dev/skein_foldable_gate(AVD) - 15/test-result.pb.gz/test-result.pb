�#
j
MainActivityFoldableGateTestapp.skein.foldable6gateSurvivesClosedFlatClosedWithoutActivityReplacement� 
�androidx.test.espresso.device.controller.DeviceControllerOperationException: Unable to connect to Emulator gRPC port. Please make sure the Android Emulator version is updated to 33.1.11+ and the controller gRPC service is enabled on the emulator. See https://developer.android.com/studio/test/espresso-api#set_up_your_project_for_the_espresso_device_api for setup instructions.
	at androidx.test.espresso.device.dagger.DeviceControllerModule.getEmulatorGRPCPortFromSystem(DeviceControllerModule.kt:106)
	at androidx.test.espresso.device.dagger.DeviceControllerModule.getEmulatorConnection(DeviceControllerModule.kt:71)
	at androidx.test.espresso.device.dagger.DeviceControllerModule.provideDeviceController(DeviceControllerModule.kt:53)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.provideDeviceController(DeviceControllerModule_ProvideDeviceControllerFactory.java:42)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.get(DeviceControllerModule_ProvideDeviceControllerFactory.java:33)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.get(DeviceControllerModule_ProvideDeviceControllerFactory.java:11)
	at androidx.test.espresso.device.internal.deps.dagger.internal.DoubleCheck.get(DoubleCheck.java:47)
	at androidx.test.espresso.device.dagger.DaggerDeviceLayerComponent$DeviceLayerComponentImpl.deviceController(DaggerDeviceLayerComponent.java:70)
	at androidx.test.espresso.device.EspressoDevice$Companion.onDevice(EspressoDevice.kt:36)
	at app.skein.foldable.MainActivityFoldableGateTest.gateSurvivesClosedFlatClosedWithoutActivityReplacement(MainActivityFoldableGateTest.kt:50)
java.lang.RuntimeException�java.lang.RuntimeException: androidx.test.espresso.device.controller.DeviceControllerOperationException: Unable to connect to Emulator gRPC port. Please make sure the Android Emulator version is updated to 33.1.11+ and the controller gRPC service is enabled on the emulator. See https://developer.android.com/studio/test/espresso-api#set_up_your_project_for_the_espresso_device_api for setup instructions.
	at androidx.test.espresso.device.dagger.DeviceControllerModule.getEmulatorGRPCPortFromSystem(DeviceControllerModule.kt:106)
	at androidx.test.espresso.device.dagger.DeviceControllerModule.getEmulatorConnection(DeviceControllerModule.kt:71)
	at androidx.test.espresso.device.dagger.DeviceControllerModule.provideDeviceController(DeviceControllerModule.kt:53)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.provideDeviceController(DeviceControllerModule_ProvideDeviceControllerFactory.java:42)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.get(DeviceControllerModule_ProvideDeviceControllerFactory.java:33)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.get(DeviceControllerModule_ProvideDeviceControllerFactory.java:11)
	at androidx.test.espresso.device.internal.deps.dagger.internal.DoubleCheck.get(DoubleCheck.java:47)
	at androidx.test.espresso.device.dagger.DaggerDeviceLayerComponent$DeviceLayerComponentImpl.deviceController(DaggerDeviceLayerComponent.java:70)
	at androidx.test.espresso.device.EspressoDevice$Companion.onDevice(EspressoDevice.kt:36)
	at app.skein.foldable.MainActivityFoldableGateTest.gateSurvivesClosedFlatClosedWithoutActivityReplacement(MainActivityFoldableGateTest.kt:50)

	at com.android.tools.androidtest.testengine.descriptor.AndroidDynamicTestDescriptor.execute(AndroidDynamicTestDescriptor.kt:68)
	at com.android.tools.androidtest.testengine.descriptor.AndroidDynamicTestDescriptor.execute(AndroidDynamicTestDescriptor.kt:36)
	at java.base/java.util.concurrent.ForkJoinTask.doExec(ForkJoinTask.java:373)
	at java.base/java.util.concurrent.ForkJoinPool$WorkQueue.topLevelExec(ForkJoinPool.java:1182)
	at java.base/java.util.concurrent.ForkJoinPool.scan(ForkJoinPool.java:1655)
	at java.base/java.util.concurrent.ForkJoinPool.runWorker(ForkJoinPool.java:1622)
	at java.base/java.util.concurrent.ForkJoinWorkerThread.run(ForkJoinWorkerThread.java:165)
"�

logcatandroid�
�/home/runner/work/skein/skein/app/build/outputs/androidTest-results/connected/debug/flavors/dev/skein_foldable_gate(AVD) - 15/logcat-app.skein.foldable.MainActivityFoldableGateTest-gateSurvivesClosedFlatClosedWithoutActivityReplacement.txt�#
g
MainActivityFoldableGateTestapp.skein.foldable3gateSurvivesOuterLandscapeWithoutExposingNavDisplay� 
�androidx.test.espresso.device.controller.DeviceControllerOperationException: Unable to connect to Emulator gRPC port. Please make sure the Android Emulator version is updated to 33.1.11+ and the controller gRPC service is enabled on the emulator. See https://developer.android.com/studio/test/espresso-api#set_up_your_project_for_the_espresso_device_api for setup instructions.
	at androidx.test.espresso.device.dagger.DeviceControllerModule.getEmulatorGRPCPortFromSystem(DeviceControllerModule.kt:106)
	at androidx.test.espresso.device.dagger.DeviceControllerModule.getEmulatorConnection(DeviceControllerModule.kt:71)
	at androidx.test.espresso.device.dagger.DeviceControllerModule.provideDeviceController(DeviceControllerModule.kt:53)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.provideDeviceController(DeviceControllerModule_ProvideDeviceControllerFactory.java:42)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.get(DeviceControllerModule_ProvideDeviceControllerFactory.java:33)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.get(DeviceControllerModule_ProvideDeviceControllerFactory.java:11)
	at androidx.test.espresso.device.internal.deps.dagger.internal.DoubleCheck.get(DoubleCheck.java:47)
	at androidx.test.espresso.device.dagger.DaggerDeviceLayerComponent$DeviceLayerComponentImpl.deviceController(DaggerDeviceLayerComponent.java:70)
	at androidx.test.espresso.device.EspressoDevice$Companion.onDevice(EspressoDevice.kt:36)
	at app.skein.foldable.MainActivityFoldableGateTest.gateSurvivesOuterLandscapeWithoutExposingNavDisplay(MainActivityFoldableGateTest.kt:85)
java.lang.RuntimeException�java.lang.RuntimeException: androidx.test.espresso.device.controller.DeviceControllerOperationException: Unable to connect to Emulator gRPC port. Please make sure the Android Emulator version is updated to 33.1.11+ and the controller gRPC service is enabled on the emulator. See https://developer.android.com/studio/test/espresso-api#set_up_your_project_for_the_espresso_device_api for setup instructions.
	at androidx.test.espresso.device.dagger.DeviceControllerModule.getEmulatorGRPCPortFromSystem(DeviceControllerModule.kt:106)
	at androidx.test.espresso.device.dagger.DeviceControllerModule.getEmulatorConnection(DeviceControllerModule.kt:71)
	at androidx.test.espresso.device.dagger.DeviceControllerModule.provideDeviceController(DeviceControllerModule.kt:53)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.provideDeviceController(DeviceControllerModule_ProvideDeviceControllerFactory.java:42)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.get(DeviceControllerModule_ProvideDeviceControllerFactory.java:33)
	at androidx.test.espresso.device.dagger.DeviceControllerModule_ProvideDeviceControllerFactory.get(DeviceControllerModule_ProvideDeviceControllerFactory.java:11)
	at androidx.test.espresso.device.internal.deps.dagger.internal.DoubleCheck.get(DoubleCheck.java:47)
	at androidx.test.espresso.device.dagger.DaggerDeviceLayerComponent$DeviceLayerComponentImpl.deviceController(DaggerDeviceLayerComponent.java:70)
	at androidx.test.espresso.device.EspressoDevice$Companion.onDevice(EspressoDevice.kt:36)
	at app.skein.foldable.MainActivityFoldableGateTest.gateSurvivesOuterLandscapeWithoutExposingNavDisplay(MainActivityFoldableGateTest.kt:85)

	at com.android.tools.androidtest.testengine.descriptor.AndroidDynamicTestDescriptor.execute(AndroidDynamicTestDescriptor.kt:68)
	at com.android.tools.androidtest.testengine.descriptor.AndroidDynamicTestDescriptor.execute(AndroidDynamicTestDescriptor.kt:36)
	at java.base/java.util.concurrent.ForkJoinTask.doExec(ForkJoinTask.java:373)
	at java.base/java.util.concurrent.ForkJoinPool$WorkQueue.topLevelExec(ForkJoinPool.java:1182)
	at java.base/java.util.concurrent.ForkJoinPool.scan(ForkJoinPool.java:1655)
	at java.base/java.util.concurrent.ForkJoinPool.runWorker(ForkJoinPool.java:1622)
	at java.base/java.util.concurrent.ForkJoinWorkerThread.run(ForkJoinWorkerThread.java:165)
"�

logcatandroid�
�/home/runner/work/skein/skein/app/build/outputs/androidTest-results/connected/debug/flavors/dev/skein_foldable_gate(AVD) - 15/logcat-app.skein.foldable.MainActivityFoldableGateTest-gateSurvivesOuterLandscapeWithoutExposingNavDisplay.txt*�

device-infoandroid�
�/home/runner/work/skein/skein/app/build/outputs/androidTest-results/connected/debug/flavors/dev/skein_foldable_gate(AVD) - 15/device-info.pb