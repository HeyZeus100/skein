import datetime, json, os, pathlib, subprocess, sys, uuid
lease = pathlib.Path('/Users/andrewherrera/skein-session-coordination/20260929/build.lock')
record = json.loads((lease / 'owner.json').read_text())
assert record['owner'] == '/root/recovery' and record['worktree'] == os.getcwd()
log = pathlib.Path(sys.argv[1])
assert not log.exists() and not log.with_suffix('.exit').exists()
record.update(pid=os.getpid(), token=record.get('token', str(uuid.uuid4())), command=sys.argv[2:], updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(lease / 'owner.json').write_text(json.dumps(record, indent=2) + '\n')
env = os.environ.copy()
env['JAVA_HOME'] = '/opt/homebrew/Cellar/openjdk@17/17.0.20.1/libexec/openjdk.jdk/Contents/Home'
env['ANDROID_HOME'] = '/Users/andrewherrera/android-sdk'
with log.open('x') as output:
    output.write(json.dumps(record) + '\n')
    output.flush()
    result = subprocess.call(sys.argv[2:], stdout=output, stderr=subprocess.STDOUT, env=env)
log.with_suffix('.exit').write_text(str(result) + '\n')
print(json.dumps({'exit': result, 'log': str(log)}))
sys.exit(result)
