import importlib.util, pathlib, selectors, subprocess
spec = importlib.util.spec_from_file_location('bridge', '/Users/andrewherrera/skein-worktrees/fold-transport-resume-20260930/build/agent-logs/fold-transport-preflight-20260930/stdin-negative-control/old-bridge.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
def run_after_fake_ready(argv, **options):
    # The 0.5-second invariant concerns blocked inherited input, not Python startup.
    deadline = options.pop('timeout')
    options.pop('check')
    options.pop('capture_output')
    payload = options.pop('input', None)
    process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **options)
    try:
        with selectors.DefaultSelector() as selector:
            selector.register(process.stderr, selectors.EVENT_READ)
            if not selector.select(timeout=5):
                raise RuntimeError('fake adb never reached the synchronized stdin read')
        if process.stderr.readline() != 'READY\n':
            raise RuntimeError('fake adb startup failed')
        stdout, stderr = process.communicate(input=payload, timeout=deadline)
        return subprocess.CompletedProcess(argv, process.returncode, stdout, stderr)
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        process.stdout.close()
        process.stderr.close()
host = m.Bridge('emulator-5554', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', pathlib.Path('build/agent-logs/fold-transport-preflight-20260930/synchronized-controls/old'), run=run_after_fake_ready,
                environment={'GITHUB_ACTIONS': 'true'})
print(host.adb('shell', '-n', '-T', 'true', timeout=0.5).stdout, flush=True)
