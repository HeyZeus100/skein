import importlib.util,pathlib,subprocess,json
spec=importlib.util.spec_from_file_location('bridge','/Users/andrewherrera/skein-worktrees/fold-transport-resume-20260930/build/agent-logs/fold-transport-preflight-20260930/stdin-negative-control/old-bridge.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
host=m.Bridge('emulator-5554','a'*32,pathlib.Path('/Users/andrewherrera/skein-worktrees/fold-transport-resume-20260930/build/agent-logs/fold-transport-preflight-20260930/stdin-negative-control/old'),environment={'GITHUB_ACTIONS':'true'})
try:
 result=host.adb('shell','-T','true',timeout=0.5)
 print(json.dumps({'outcome':'completed','stdout':result.stdout,'returncode':result.returncode}))
except subprocess.TimeoutExpired as error:
 print(json.dumps({'outcome':'timeout','timeout':error.timeout,'poisoned':host.poisoned}))
