# Local workspace evidence

Read `capsule-review.json.gz`, `execution-attribution.json.gz`, and `all-image-pair-provenance.json.gz` for exact source, task execution and byte provenance.

Source chain: failed screenshots and successful synthetic production app captures at5d58f7cba; input-mode focus fix bc0f2ad81; combined source0401d15f1; approved110 golden-only commit28354dd25. The6 synthetic app images show note+chat, two different notes and note+graph in both test variants. They are host captures, never private physical-device screenshots.

The full owning-worker archive retains every before/actual/compare image for all110 intentional changes, all4 rejected Models color changes, and each final recorded golden. It also retains original failure XML/JSON, successful check3 rawXML, original appcheck2 XML/captures, focus-fix evidence and final verification results. `FULL_LOCAL_SHA256SUMS` indexes every byte. This bounded portable copy retains complete raw XML/JSON (lossless gzip where useful), all image provenance/hashes and representative phone/Fold comparisons; the complete image bytes remain in the adjacent full directory. No failed evidence was replaced.

Combined source:1728cases1684pass44priorconditional skips; no failures/errors. All44skip identities independently match prior8a CI. App check2:562pass, no skips. Screenshot verification:552individual unchanged results; zero added/changed/recorded, and actual XML has no failures/errors. Seven module screenshot test tasks execute; Models is UP-TO-DATE from the38unchanged focused fix run, preserved here. Requested check/ktlint/opt-in compilation task statuses are explicitly recorded, including UP-TO-DATE reuse.

Initial screenshots had114changed images. Peers inspected them;4Models focus-color changes were repaired against unchanged goldens. Only110approved icon/chat/editor PNG paths were recorded. Their new bytes exactly equal their reviewed first-attempt actual PNGs; every other prior golden remains byte-identical. Sources and thresholds were not changed by this evidence assembly.

No new APK, installed candidate, emulator instrumentation runtime, physical hardware, retrieval-quality or embedding-quality acceptance is claimed. The fold test observer compiles here; its runtime gate remains independent.
